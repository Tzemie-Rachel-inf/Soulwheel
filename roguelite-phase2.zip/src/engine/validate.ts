import type { GameConfig } from './types';

export interface ValidationReport {
  /** The config is broken: a spin will throw. */
  errors: string[];
  /** Legal but suspicious: worth a look. */
  warnings: string[];
}

/**
 * Static checks on the wheel graph. Run it once at startup (and in tests) so a typo
 * in a `nextStepId` fails loudly on load instead of halfway through a spin.
 *
 * Errors:   missing entry step, broken nextStepId, unknown trait, bad weight,
 *           duplicate option id, step/trait key that doesn't match its id.
 * Warnings: a wheel with no always-available option (it can throw NO_ELIGIBLE_OPTIONS),
 *           unreachable wheels, and cycles (allowed, but capped by MAX_GENERATION_STEPS).
 */
export function validateGameConfig(config: GameConfig): ValidationReport {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!config.steps[config.entryStepId]) {
    errors.push(`entryStepId "${config.entryStepId}" does not match any wheel.`);
  }

  for (const [key, trait] of Object.entries(config.traits)) {
    if (trait.id !== key) errors.push(`Trait registered as "${key}" has id "${trait.id}".`);
  }

  for (const [key, step] of Object.entries(config.steps)) {
    if (step.id !== key) errors.push(`Wheel registered as "${key}" has id "${step.id}".`);
    if (step.options.length === 0) errors.push(`Wheel "${key}" has no options.`);

    const seen = new Set<string>();
    for (const option of step.options) {
      const where = `${key} › ${option.id}`;
      if (seen.has(option.id)) errors.push(`${where}: duplicate option id.`);
      seen.add(option.id);

      if (!Number.isFinite(option.baseWeight) || option.baseWeight < 0) {
        errors.push(`${where}: baseWeight must be a finite number ≥ 0.`);
      }
      if (option.nextStepId !== null && !config.steps[option.nextStepId]) {
        errors.push(`${where}: nextStepId "${option.nextStepId}" does not match any wheel.`);
      }
      for (const traitId of option.grantTraits ?? []) {
        if (!config.traits[traitId]) errors.push(`${where}: unknown trait "${traitId}".`);
      }
      if (option.claimSingleton !== undefined && option.claimSingleton.trim() === '') {
        errors.push(`${where}: claimSingleton must be a non-empty key.`);
      }
    }

    // An option that no world state can lock or fade to zero.
    const hasFallback = step.options.some(
      (o) => !o.condition && !o.claimSingleton && o.baseWeight > 0 && (o.threatScaling ?? 0) >= 0,
    );
    if (!hasFallback) {
      warnings.push(`Wheel "${key}" has no always-available option; some worlds could make it unspinnable.`);
    }
  }

  // Reachability and cycles, by depth-first search from the entry wheel.
  const visiting = new Set<string>();
  const visited = new Set<string>();
  const visit = (id: string, path: string[]): void => {
    if (visiting.has(id)) {
      warnings.push(`Cycle: ${[...path, id].join(' → ')} (allowed, but capped per character).`);
      return;
    }
    if (visited.has(id)) return;
    const step = config.steps[id];
    if (!step) return; // already reported above
    visiting.add(id);
    for (const next of new Set(step.options.map((o) => o.nextStepId))) {
      if (next !== null) visit(next, [...path, id]);
    }
    visiting.delete(id);
    visited.add(id);
  };
  visit(config.entryStepId, []);

  for (const key of Object.keys(config.steps)) {
    if (!visited.has(key)) warnings.push(`Wheel "${key}" is unreachable from "${config.entryStepId}".`);
  }

  return { errors, warnings };
}
