import { EngineError } from './errors';
import { createId, defaultRng, type Rng } from './rng';
import { STAT_KEYS, type Character, type GameConfig, type ResolvedSlice, type StatBlock } from './types';

/** Upper bound for `Character.weaponTier`. Tier 10 is worth 250 CP. */
export const MAX_WEAPON_TIER = 10;

export interface CreateCharacterOptions {
  name?: string;
  /** Used for the id. Pass the run's seeded RNG to make ids reproducible. */
  rng?: Rng;
  /** Timestamp override, for deterministic tests. */
  now?: number;
}

/** A fresh, uncommitted character with the config's base stats and nothing else. */
export function createCharacter(
  config: GameConfig,
  { name = 'Nameless Wanderer', rng = defaultRng, now = Date.now() }: CreateCharacterOptions = {},
): Character {
  return {
    id: createId('chr', rng),
    name,
    createdAt: now,
    role: 'hero',
    status: 'rolling',
    stats: { ...config.baseStats },
    weaponTier: 0,
    traits: [],
    tags: [],
    singletonClaims: [],
    history: [],
  };
}

/**
 * Apply a rolled slice to a character. Pure: returns a new Character, never mutates.
 *
 * - Stats change by `statModifiers` and floor at 0.
 * - Weapon tier changes by `weaponTierDelta`, clamped to [0, MAX_WEAPON_TIER].
 * - Traits are copied from config (snapshots); a trait already owned is skipped.
 * - Tags and singleton claims are set-unions.
 * - The roll is appended to `history` with the probability it had.
 *
 * @throws EngineError('UNKNOWN_TRAIT') if the option grants a trait missing from config.
 */
export function applyOption(
  char: Character,
  slice: ResolvedSlice,
  stepId: string,
  config: GameConfig,
): Character {
  const { option } = slice;

  const stats: StatBlock = { ...char.stats };
  for (const key of STAT_KEYS) {
    stats[key] = Math.max(0, stats[key] + (option.statModifiers?.[key] ?? 0));
  }

  const weaponTier = clamp(char.weaponTier + (option.weaponTierDelta ?? 0), 0, MAX_WEAPON_TIER);

  const traits = [...char.traits];
  for (const traitId of option.grantTraits ?? []) {
    if (traits.some((t) => t.id === traitId)) continue;
    const def = config.traits[traitId];
    if (!def) {
      throw new EngineError(
        'UNKNOWN_TRAIT',
        `Option "${option.id}" on step "${stepId}" grants unknown trait "${traitId}".`,
      );
    }
    traits.push({ ...def });
  }

  return {
    ...char,
    role: option.setRole ?? char.role,
    stats,
    weaponTier,
    traits,
    tags: union(char.tags, option.grantTags),
    singletonClaims: union(char.singletonClaims, option.claimSingleton ? [option.claimSingleton] : []),
    history: [...char.history, { stepId, optionId: option.id, probability: slice.probability }],
  };
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function union<T>(base: readonly T[], extra: readonly T[] = []): T[] {
  return [...new Set([...base, ...extra])];
}
