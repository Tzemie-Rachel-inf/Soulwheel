import { EngineError } from './errors';
import { createId, defaultRng, type Rng } from './rng';
import type { Character, SingletonKey, World } from './types';

export function createWorld({ rng = defaultRng, now = Date.now() }: { rng?: Rng; now?: number } = {}): World {
  return {
    schemaVersion: 2,
    id: createId('wld', rng),
    createdAt: now,
    activeSingletons: {},
    roster: [],
    graveyard: [],
    hallOfFame: [],
    threatLevel: 0,
  };
}

// ─── Singletons: generic over any string key ───────────────────────────────

/** True when someone holds this one-of-a-kind role. Works for any key, known or not. */
export function isSingletonClaimed(world: World, key: SingletonKey): boolean {
  return Object.hasOwn(world.activeSingletons, key);
}

/** Id of the character holding this role, if any. */
export function getSingletonHolderId(world: World, key: SingletonKey): string | undefined {
  return isSingletonClaimed(world, key) ? world.activeSingletons[key] : undefined;
}

/** The living character holding this role, if any. */
export function getSingletonHolder(world: World, key: SingletonKey): Character | undefined {
  const id = getSingletonHolderId(world, key);
  return id === undefined ? undefined : world.roster.find((c) => c.id === id);
}

/**
 * Free every role a character holds (on death, retirement, victory...). Pure.
 * The matching wheel options unlock on the next roll.
 */
export function releaseSingletons(world: World, characterId: string): World {
  const activeSingletons = Object.fromEntries(
    Object.entries(world.activeSingletons).filter(([, holderId]) => holderId !== characterId),
  );
  return { ...world, activeSingletons };
}

// ─── Lifecycle ──────────────────────────────────────────────────────────────

/**
 * Place a freshly rolled character into the world. Pure: returns a new World.
 *
 * The character becomes `alive`, joins the roster, and only now are its
 * `singletonClaims` written into `activeSingletons`, whatever their keys.
 * Abandoning a half-rolled character therefore never leaves a phantom holder behind.
 *
 * @throws EngineError('INVALID_STATUS') if the character isn't `rolling`.
 * @throws EngineError('SINGLETON_CONFLICT') if a claimed role was taken in the meantime.
 */
export function commitCharacter(world: World, char: Character): World {
  if (char.status !== 'rolling') {
    throw new EngineError('INVALID_STATUS', `Only rolling characters can be committed (got "${char.status}").`);
  }

  let activeSingletons = world.activeSingletons;
  for (const key of char.singletonClaims) {
    const holder = getSingletonHolderId(world, key);
    if (holder !== undefined) {
      throw new EngineError('SINGLETON_CONFLICT', `"${key}" is already held by ${holder}; ${char.id} cannot claim it.`);
    }
    // Computed keys in an object literal always create an own property, so even
    // a key like "__proto__" is stored as data rather than touching the prototype.
    activeSingletons = { ...activeSingletons, [key]: char.id };
  }

  return {
    ...world,
    activeSingletons,
    roster: [...world.roster, { ...char, status: 'alive' }],
  };
}
