/**
 * Core data model for the Roguelite Character Generator & World Simulator.
 *
 * Two families of types live here, and they are kept deliberately apart:
 *
 *  1. PERSISTED STATE: `World`, `Character`, `Trait`, `RollRecord`.
 *     Plain JSON. Saved to localStorage. Never contains functions.
 *
 *  2. CONFIG: `GameConfig`, `WheelStep`, `WheelOption`.
 *     Lives in code. May contain functions (`condition`, `lockedReason`), so it is
 *     never serialized. Persisted state refers to config by id only, and snapshots
 *     anything that must survive future rebalancing (traits).
 *
 * Combat Power is intentionally NOT stored anywhere. It is derived on demand by
 * `calculatePowerRating`, so it can never drift out of sync with what was rolled.
 */

// ─── Stats ──────────────────────────────────────────────────────────────────

export const STAT_KEYS = ['might', 'agility', 'intellect', 'arcana', 'vitality'] as const;
export type StatKey = (typeof STAT_KEYS)[number];
export type StatBlock = Record<StatKey, number>;

// ─── Persisted state: Character ─────────────────────────────────────────────

export type CharacterRole = 'hero' | 'demonLord';

/**
 * Lifecycle:  rolling ──commitCharacter──▶ alive ──▶ fallen | victorious
 *
 * A `rolling` character exists only inside the generation loop. It has no effect
 * on the World until it is committed.
 */
export type CharacterStatus = 'rolling' | 'alive' | 'fallen' | 'victorious';

/** A trait as stored on a character: a frozen copy of its config definition. */
export interface Trait {
  id: string;
  name: string;
  description: string;
  /** Flat Combat Power this trait contributes (the "Trait Modifiers" term). May be negative. */
  power: number;
}

/** One spin's outcome, kept on the character for history, replays and UI flair. */
export interface RollRecord {
  stepId: string;
  optionId: string;
  /** The chance this option had at the moment it was rolled (0–1). */
  probability: number;
}

export interface Character {
  id: string;
  name: string;
  createdAt: number;
  role: CharacterRole;
  status: CharacterStatus;
  stats: StatBlock;
  /** 0 = bare hands. Each tier is worth `WEAPON_TIER_CP` Combat Power. */
  weaponTier: number;
  /** Snapshots, so a fallen hero keeps their power even if the config is rebalanced later. */
  traits: Trait[];
  /** Free-form flags that wheel conditions can read, e.g. 'cursed', 'blessed'. */
  tags: string[];
  /** One-of-a-kind roles this character will hold once committed to the world. */
  singletonClaims: SingletonKey[];
  /** Every spin, in order. The path through the wheel graph. */
  history: RollRecord[];
  /** Set when the character leaves play (graveyard or hall of fame). Phase 3. */
  fate?: { at: number; summary: string };
}

// ─── Persisted state: World ─────────────────────────────────────────────────

/**
 * Any string names a one-of-a-kind role: 'demon_lord', 'chosen_hero', 'archmage', ...
 * The engine never lists them. A key comes into existence the moment a config
 * option declares `claimSingleton: '<key>'`.
 */
export type SingletonKey = string;

/**
 * Who holds each one-of-a-kind role.
 *
 *   key present  → claimed; the value is the holder's Character id
 *   key absent   → free
 *
 * There is no list of keys anywhere in the engine, so adding a new role is a
 * config-only change.
 */
export type ActiveSingletons = Record<SingletonKey, string>;

export interface World {
  /** Bump when the persisted shape changes; `loadWorld` rejects other versions. */
  schemaVersion: 2;
  id: string;
  createdAt: number;
  activeSingletons: ActiveSingletons;
  /** Characters currently in play: living heroes and the reigning Demon Lord. */
  roster: Character[];
  graveyard: Character[];
  hallOfFame: Character[];
  /**
   * Global danger dial. 0 = peaceful; the sample content is tuned for roughly 0–5.
   * It bends option weights through `WheelOption.threatScaling`, so the world's
   * history shapes every future roll.
   */
  threatLevel: number;
}

// ─── Config: the wheel graph ────────────────────────────────────────────────

/** Reads the world and the character being rolled. Must be pure. */
export type WorldPredicate = (world: World, char: Character) => boolean;
/** Static text, or text computed from the current world and character. */
export type WorldText = string | ((world: World, char: Character) => string);

export interface WheelOption {
  /** Unique within its step. Stored in `RollRecord`, so treat it as permanent. */
  id: string;
  label: string;
  description?: string;

  // ── Odds ──
  /** Relative weight before world modifiers. 0 keeps the slice on the wheel but unrollable. */
  baseWeight: number;
  /**
   * How strongly `world.threatLevel` bends this option's odds:
   *   effectiveWeight = baseWeight × max(0, 1 + threatScaling × threatLevel)
   * Positive = more likely in dark times. Negative = fades out as threat rises.
   */
  threatScaling?: number;

  // ── Effects on the character ──
  /** Added to the character's stats. Negative values allowed; stats floor at 0. */
  statModifiers?: Partial<StatBlock>;
  /** Added to weapon tier, clamped to [0, MAX_WEAPON_TIER]. */
  weaponTierDelta?: number;
  /** Ids into `GameConfig.traits`. Already-owned traits are not granted twice. */
  grantTraits?: string[];
  grantTags?: string[];
  setRole?: CharacterRole;
  /**
   * Make this option a one-of-a-kind role. Any string works ('demon_lord', 'archmage').
   * The engine locks the option while `world.activeSingletons[key]` exists, and
   * `commitCharacter` writes the key. Abandoning a half-rolled character claims nothing.
   */
  claimSingleton?: SingletonKey;

  // ── Graph ──
  /** The next wheel to spin, or null to finish generation. Required, so leaves are explicit. */
  nextStepId: string | null;

  // ── Availability ──
  /** Extra availability rule. `false` → slice is drawn grayed out with a lock, weight becomes 0. */
  condition?: WorldPredicate;
  /** Tooltip for a locked slice. Defaults to a generic message. */
  lockedReason?: WorldText;

  // ── Presentation hints (the engine never reads these) ──
  /** Slice fill colour (hex). */
  color?: string;
  /** lucide-react icon name, e.g. 'Crown'. */
  icon?: string;
}

export interface WheelStep {
  id: string;
  title: string;
  subtitle?: string;
  /** Rendered clockwise in this order. Order also defines `ResolvedSlice.index`. */
  options: WheelOption[];
}

export interface GameConfig {
  /** The first wheel every character spins. */
  entryStepId: string;
  /** Every wheel, keyed by its id. */
  steps: Record<string, WheelStep>;
  /** Trait definitions. Options grant these by id; characters store copies. */
  traits: Record<string, Trait>;
  /** Starting stats for every new character. */
  baseStats: StatBlock;
}

// ─── Engine outputs ─────────────────────────────────────────────────────────

/** One option evaluated against the current world and character. One per visual slice. */
export interface ResolvedSlice {
  option: WheelOption;
  /** Position on the wheel, matching the order of `WheelStep.options`. */
  index: number;
  locked: boolean;
  /** Why the slice is locked, ready to show in a tooltip. Null when unlocked. */
  lockReason: string | null;
  /** The weight the RNG actually uses. Always 0 when locked. */
  effectiveWeight: number;
  /** effectiveWeight / total of all effective weights, 0–1. */
  probability: number;
}

export interface RollResult {
  /** Every slice, locked ones included. Render all of them. */
  slices: ResolvedSlice[];
  /** The winner, decided before any animation. Spin the wheel to `winner.index`. */
  winner: ResolvedSlice;
  /** The raw RNG draw in [0, 1). Log it to replay or debug a roll. */
  draw: number;
}
