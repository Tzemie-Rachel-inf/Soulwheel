import type { ActiveSingletons, World } from './types';

export const WORLD_STORAGE_KEY = 'roguelite.world';

/** The slice of the Web Storage API we use. `localStorage` satisfies it; so does a Map-backed fake. */
export interface StorageLike {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export function saveWorld(world: World, storage: StorageLike = localStorage): void {
  storage.setItem(WORLD_STORAGE_KEY, JSON.stringify(world));
}

/**
 * Load the saved world, or `null` if there is none or it can't be trusted
 * (corrupt JSON, wrong shape, a schema version other than 2). Never throws.
 *
 * Singleton entries whose value isn't a character id are dropped, so a damaged
 * save can never lock a role forever.
 */
export function loadWorld(storage: StorageLike = localStorage): World | null {
  const raw = storage.getItem(WORLD_STORAGE_KEY);
  if (raw === null) return null;

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!isWorldShape(parsed)) return null;

  return { ...parsed, activeSingletons: sanitizeSingletons(parsed.activeSingletons) };
}

export function clearWorld(storage: StorageLike = localStorage): void {
  storage.removeItem(WORLD_STORAGE_KEY);
}

function sanitizeSingletons(value: unknown): ActiveSingletons {
  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>).filter(
      (entry): entry is [string, string] => typeof entry[1] === 'string' && entry[1].length > 0,
    ),
  );
}

/** A structural check of the top-level shape, not a full schema validation. */
function isWorldShape(value: unknown): value is World {
  if (typeof value !== 'object' || value === null) return false;
  const w = value as Record<string, unknown>;
  return (
    w.schemaVersion === 2 &&
    typeof w.id === 'string' &&
    typeof w.threatLevel === 'number' &&
    typeof w.activeSingletons === 'object' &&
    w.activeSingletons !== null &&
    !Array.isArray(w.activeSingletons) &&
    Array.isArray(w.roster) &&
    Array.isArray(w.graveyard) &&
    Array.isArray(w.hallOfFame)
  );
}
