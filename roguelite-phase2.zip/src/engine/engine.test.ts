import { describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../config/gameConfig';
import {
  EngineError,
  isSingletonClaimed,
  releaseSingletons,
  applyOption,
  calculatePowerRating,
  calculateWinProbability,
  commitCharacter,
  createCharacter,
  createSeededRng,
  createWorld,
  getPowerBreakdown,
  getStep,
  loadWorld,
  resolveSlices,
  rollFullCharacter,
  rollWeightedOption,
  saveWorld,
  validateGameConfig,
  type Character,
  type GameConfig,
  type Rng,
  type StorageLike,
  type WheelOption,
  type World,
} from './index';

// ─── helpers ────────────────────────────────────────────────────────────────

const fate = getStep(GAME_CONFIG, 'fate');
const talents = getStep(GAME_CONFIG, 'talents');
const abyssal = getStep(GAME_CONFIG, 'abyssal');

const freshWorld = (seed = 1): World => createWorld({ rng: createSeededRng(seed), now: 0 });
const freshChar = (seed = 2): Character => createCharacter(GAME_CONFIG, { rng: createSeededRng(seed), now: 0 });

function expectEngineError(fn: () => unknown, code: EngineError['code']): void {
  let caught: unknown;
  try {
    fn();
  } catch (err) {
    caught = err;
  }
  expect(caught instanceof EngineError).toBe(true);
  expect((caught as EngineError).code).toBe(code);
}

/** Roll characters until one satisfies `predicate` (without committing any). */
function rollUntil(world: World, rng: Rng, predicate: (c: Character) => boolean): Character {
  for (let i = 0; i < 2000; i++) {
    const { character } = rollFullCharacter(GAME_CONFIG, world, rng, { now: 0 });
    if (predicate(character)) return character;
  }
  throw new Error('rollUntil: predicate never satisfied');
}

/** Put n fake corpses in the graveyard. */
function withGraveyard(world: World, n: number): World {
  return { ...world, graveyard: Array.from({ length: n }, (_, i) => ({ ...freshChar(100 + i), status: 'fallen' as const })) };
}

// ─── config ─────────────────────────────────────────────────────────────────

describe('validateGameConfig', () => {
  it('passes the sample config with no errors or warnings', () => {
    const report = validateGameConfig(GAME_CONFIG);
    expect(report.errors).toEqual([]);
    expect(report.warnings).toEqual([]);
  });

  it('catches a broken nextStepId, an unknown trait and a negative weight', () => {
    const broken = {
      ...GAME_CONFIG,
      steps: {
        ...GAME_CONFIG.steps,
        fate: {
          ...fate,
          options: [{ id: 'oops', label: 'Oops', baseWeight: -1, grantTraits: ['nope'], nextStepId: 'nowhere' }],
        },
      },
    };
    const { errors } = validateGameConfig(broken);
    expect(errors).toHaveLength(3);
  });
});

// ─── rollWeightedOption ─────────────────────────────────────────────────────

describe('rollWeightedOption', () => {
  it('matches the configured odds over many seeded draws', () => {
    const world = freshWorld();
    const char = freshChar();
    const rng = createSeededRng(42);
    const N = 40_000;
    const counts = new Map<string, number>();
    for (let i = 0; i < N; i++) {
      const id = rollWeightedOption(fate.options, world, char, rng).winner.option.id;
      counts.set(id, (counts.get(id) ?? 0) + 1);
    }
    for (const slice of resolveSlices(fate.options, world, char)) {
      expect((counts.get(slice.option.id) ?? 0) / N).toBeCloseTo(slice.probability, 2);
    }
  });

  it('never picks a locked slice, but still returns it for rendering', () => {
    let world = freshWorld();
    const rng = createSeededRng(7);
    const lord = rollUntil(world, rng, (c) => c.role === 'demonLord');
    world = commitCharacter(world, lord);

    const char = freshChar();
    for (let i = 0; i < 5_000; i++) {
      const { winner, slices } = rollWeightedOption(fate.options, world, char, rng);
      expect(winner.option.id === 'demon_lord').toBe(false);
      expect(slices).toHaveLength(fate.options.length);
    }

    const lordSlice = resolveSlices(fate.options, world, char).find((s) => s.option.id === 'demon_lord');
    expect(lordSlice?.locked).toBe(true);
    expect(lordSlice?.effectiveWeight).toBe(0);
    expect(lordSlice?.probability).toBe(0);
    expect(lordSlice?.lockReason).toBe('A Demon Lord already reigns over this world');
  });

  it('reports winner.index as the position on the wheel', () => {
    const { winner } = rollWeightedOption(fate.options, freshWorld(), freshChar(), () => 0.999999);
    expect(winner.index).toBe(fate.options.length - 1);
    expect(fate.options[winner.index]?.id).toBe(winner.option.id);
  });

  it('skips a locked slice even when the draw lands where it would sit', () => {
    // b sits between a and c with a huge base weight, but it's locked, so the draw
    // is split 50/50 between a and c only.
    const opts: WheelOption[] = [
      { id: 'a', label: 'A', baseWeight: 1, nextStepId: null },
      { id: 'b', label: 'B', baseWeight: 1000, nextStepId: null, condition: () => false },
      { id: 'c', label: 'C', baseWeight: 1, nextStepId: null },
    ];
    expect(rollWeightedOption(opts, freshWorld(), freshChar(), () => 0.49).winner.option.id).toBe('a');
    expect(rollWeightedOption(opts, freshWorld(), freshChar(), () => 0.51).winner.option.id).toBe('c');
  });

  it('throws NO_ELIGIBLE_OPTIONS when every slice is locked', () => {
    const allLocked: WheelOption[] = [
      { id: 'x', label: 'X', baseWeight: 1, nextStepId: null, condition: () => false },
      { id: 'y', label: 'Y', baseWeight: 0, nextStepId: null },
    ];
    expectEngineError(() => rollWeightedOption(allLocked, freshWorld(), freshChar()), 'NO_ELIGIBLE_OPTIONS');
  });

  it('lets threatLevel bend the odds', () => {
    const calm = freshWorld();
    const dark = { ...calm, threatLevel: 4 };
    const p = (world: World, id: string) =>
      resolveSlices(fate.options, world, freshChar()).find((s) => s.option.id === id)?.probability ?? 0;
    expect(p(dark, 'cursed')).toBeGreaterThan(p(calm, 'cursed'));
    expect(p(dark, 'blessed')).toBeLessThan(p(calm, 'blessed'));
  });

  it('explains locks with dynamic reasons', () => {
    const world = withGraveyard(freshWorld(), 1);
    const slices = resolveSlices(talents.options, world, freshChar());
    const reason = (id: string) => slices.find((s) => s.option.id === id)?.lockReason;
    expect(reason('arcane_savant')).toBe('Requires 12 Arcana (you have 10)');
    expect(reason('echoes')).toBe('Requires 3 souls in the graveyard (1/3)');
    expect(reason('holy_sword')).toBe('The Holy Sword sleeps until a Demon Lord rises');
    expect(reason('archmage')).toBe('Requires 13 Arcana (you have 10)');
    expect(reason('blademaster')).toBeNull();
  });

  it('unlocks world-gated slices once the world changes', () => {
    const slices = resolveSlices(abyssal.options, withGraveyard(freshWorld(), 5), freshChar());
    expect(slices.find((s) => s.option.id === 'lich_king')?.locked).toBe(false);
  });
});

// ─── calculatePowerRating ───────────────────────────────────────────────────

describe('calculatePowerRating', () => {
  it('follows CP = stats + weaponTier × 25 + traits', () => {
    const char: Character = {
      ...freshChar(),
      weaponTier: 3,
      traits: [
        { id: 'a', name: 'A', description: '', power: 40 },
        { id: 'b', name: 'B', description: '', power: -10 },
      ],
    };
    expect(getPowerBreakdown(char)).toEqual({ stats: 50, weapon: 75, traits: 30, total: 155 });
    expect(calculatePowerRating(char)).toBe(155);
  });

  it('never goes negative', () => {
    const char: Character = { ...freshChar(), traits: [{ id: 'doom', name: 'Doom', description: '', power: -999 }] };
    expect(calculatePowerRating(char)).toBe(0);
  });

  it('turns CP into a weighted win chance, not a coin flip', () => {
    expect(calculateWinProbability(100, 300)).toBe(0.25);
    expect(calculateWinProbability(300, 100)).toBe(0.75);
    expect(calculateWinProbability(0, 0)).toBe(0.5);
  });
});

// ─── generation loop & world ────────────────────────────────────────────────

describe('generation loop', () => {
  it('walks the graph until nextStepId is null, branching on the Fate roll', () => {
    const world = freshWorld();
    const rng = createSeededRng(99);
    for (let i = 0; i < 500; i++) {
      const { character } = rollFullCharacter(GAME_CONFIG, world, rng, { now: 0 });
      const path = character.history.map((h) => h.stepId).join('>');
      const expected =
        character.role === 'demonLord'
          ? 'fate>abyssal'
          : character.singletonClaims.includes('holy_sword_bearer')
            ? 'fate>talents' // the Holy Sword skips the Armory
            : 'fate>talents>armory';
      expect(path).toBe(expected);
      expect(character.status).toBe('rolling');
    }
  });

  it('applyOption never mutates its input', () => {
    const char = freshChar();
    const before = JSON.stringify(char);
    const slice = resolveSlices(fate.options, freshWorld(), char).find((s) => s.option.id === 'demon_lord');
    if (!slice) throw new Error('missing slice');
    const after = applyOption(char, slice, 'fate', GAME_CONFIG);
    expect(JSON.stringify(char)).toBe(before);
    expect(after.role).toBe('demonLord');
    expect(after.singletonClaims).toEqual(['demon_lord']);
  });

  it('is reproducible from a seed', () => {
    const a = rollFullCharacter(GAME_CONFIG, freshWorld(), createSeededRng(5), { now: 0 }).character;
    const b = rollFullCharacter(GAME_CONFIG, freshWorld(), createSeededRng(5), { now: 0 }).character;
    expect(a).toEqual(b);
  });
});

describe('Demon Lord singleton', () => {
  it('is only written to the world on commit', () => {
    const world = freshWorld();
    const lord = rollUntil(world, createSeededRng(3), (c) => c.role === 'demonLord');
    expect(isSingletonClaimed(world, 'demon_lord')).toBe(false);
    expect(commitCharacter(world, lord).activeSingletons).toEqual({ demon_lord: lord.id });
  });

  it('holds across every later character', () => {
    const rng = createSeededRng(11);
    let world = freshWorld();
    const lord = rollUntil(world, rng, (c) => c.role === 'demonLord');
    world = commitCharacter(world, lord);
    for (let i = 0; i < 1_000; i++) {
      const { character } = rollFullCharacter(GAME_CONFIG, world, rng, { now: 0 });
      expect(character.role).toBe('hero');
    }
  });

  it('rejects a stale claim if another Demon Lord was committed first', () => {
    const rng = createSeededRng(21);
    const world = freshWorld();
    const first = rollUntil(world, rng, (c) => c.role === 'demonLord');
    const second = rollUntil(world, rng, (c) => c.role === 'demonLord');
    const afterFirst = commitCharacter(world, first);
    expectEngineError(() => commitCharacter(afterFirst, second), 'SINGLETON_CONFLICT');
  });

  it('wakes the Holy Sword, which is then a singleton too', () => {
    const rng = createSeededRng(31);
    let world = freshWorld();
    world = commitCharacter(world, rollUntil(world, rng, (c) => c.role === 'demonLord'));
    const bearer = rollUntil(world, rng, (c) => c.singletonClaims.includes('holy_sword_bearer'));
    expect(bearer.tags.includes('cursed')).toBe(false);
    world = commitCharacter(world, bearer);
    const reason = resolveSlices(talents.options, world, freshChar()).find((s) => s.option.id === 'holy_sword')?.lockReason;
    expect(reason).toBe('The Holy Sword has already chosen a bearer');
  });
});

// ─── generic singletons ──────────────────────────────────────────────────────

describe('generic singletons', () => {
  /** A two-wheel config invented on the spot, with role keys the engine has never seen. */
  const origin: GameConfig = {
    entryStepId: 'origin',
    baseStats: GAME_CONFIG.baseStats,
    traits: {},
    steps: {
      origin: {
        id: 'origin',
        title: 'Origin',
        options: [
          { id: 'chosen', label: 'Chosen Hero', baseWeight: 1, claimSingleton: 'chosen_hero', nextStepId: 'calling' },
          { id: 'commoner', label: 'Commoner', baseWeight: 3, nextStepId: 'calling' },
        ],
      },
      calling: {
        id: 'calling',
        title: 'Calling',
        options: [
          { id: 'archmage', label: 'Archmage', baseWeight: 1, claimSingleton: 'archmage', nextStepId: null },
          { id: 'farmer', label: 'Farmer', baseWeight: 1, nextStepId: null },
        ],
      },
    },
  };
  const rollOrigin = (world: World, rng: Rng) => rollFullCharacter(origin, world, rng, { now: 0 }).character;

  it('locks and writes any key a config invents, with no engine changes', () => {
    const rng = createSeededRng(41);
    let world = freshWorld();
    let hero = rollOrigin(world, rng);
    while (!hero.singletonClaims.includes('chosen_hero')) hero = rollOrigin(world, rng);
    world = commitCharacter(world, hero);

    expect(isSingletonClaimed(world, 'chosen_hero')).toBe(true);
    expect(world.activeSingletons['chosen_hero']).toBe(hero.id);

    const slice = resolveSlices(getStep(origin, 'origin').options, world, freshChar())[0];
    expect(slice?.locked).toBe(true);
    expect(slice?.lockReason).toBe('Already claimed in this world');
    for (let i = 0; i < 2_000; i++) {
      expect(rollOrigin(world, rng).singletonClaims.includes('chosen_hero')).toBe(false);
    }
  });

  it('lets one character hold several roles, each tracked independently', () => {
    const rng = createSeededRng(43);
    let world = freshWorld();
    let both = rollOrigin(world, rng);
    while (both.singletonClaims.length < 2) both = rollOrigin(world, rng);
    world = commitCharacter(world, both);
    expect(world.activeSingletons).toEqual({ chosen_hero: both.id, archmage: both.id });

    for (let i = 0; i < 500; i++) expect(rollOrigin(world, rng).singletonClaims).toEqual([]);
  });

  it('releaseSingletons frees every role the character held, and only theirs', () => {
    const world: World = {
      ...freshWorld(),
      activeSingletons: { chosen_hero: 'chr_a', archmage: 'chr_a', demon_lord: 'chr_b' },
    };
    const released = releaseSingletons(world, 'chr_a');
    expect(released.activeSingletons).toEqual({ demon_lord: 'chr_b' });
    expect(resolveSlices(getStep(origin, 'origin').options, released, freshChar())[0]?.locked).toBe(false);
    expect(world.activeSingletons['chosen_hero']).toBe('chr_a'); // input untouched
  });

  it('treats unusual keys as plain data', () => {
    const odd: WheelOption[] = [{ id: 'p', label: 'P', baseWeight: 1, claimSingleton: '__proto__', nextStepId: null }];
    const char = applyOption(freshChar(), resolveSlices(odd, freshWorld(), freshChar())[0]!, 's', origin);
    const world = commitCharacter(freshWorld(), char);
    expect(Object.getPrototypeOf(world.activeSingletons)).toBe(Object.prototype);
    expect(isSingletonClaimed(world, '__proto__')).toBe(true);
    expect(isSingletonClaimed(world, 'toString')).toBe(false);
  });
});

// ─── persistence ────────────────────────────────────────────────────────────

describe('persistence', () => {
  const memoryStorage = (): StorageLike => {
    const map = new Map<string, string>();
    return {
      getItem: (k) => map.get(k) ?? null,
      setItem: (k, v) => void map.set(k, v),
      removeItem: (k) => void map.delete(k),
    };
  };

  it('round-trips a world through storage', () => {
    const storage = memoryStorage();
    const rng = createSeededRng(8);
    let world = freshWorld();
    world = commitCharacter(world, rollFullCharacter(GAME_CONFIG, world, rng, { now: 0 }).character);
    saveWorld(world, storage);
    expect(loadWorld(storage)).toEqual(world);
  });

  it('returns null for missing or corrupt saves', () => {
    const storage = memoryStorage();
    expect(loadWorld(storage)).toBeNull();
    storage.setItem('roguelite.world', '{not json');
    expect(loadWorld(storage)).toBeNull();
    storage.setItem('roguelite.world', JSON.stringify({ schemaVersion: 99 }));
    expect(loadWorld(storage)).toBeNull();
  });

  it('rejects saves from the old schema version', () => {
    const storage = memoryStorage();
    storage.setItem('roguelite.world', JSON.stringify({ ...freshWorld(), schemaVersion: 1 }));
    expect(loadWorld(storage)).toBeNull();
  });

  it('drops malformed singleton entries instead of locking a role forever', () => {
    const storage = memoryStorage();
    const damaged = { ...freshWorld(), activeSingletons: { demon_lord: 'chr_x', archmage: null, chosen_hero: 42 } };
    storage.setItem('roguelite.world', JSON.stringify(damaged));
    expect(loadWorld(storage)?.activeSingletons).toEqual({ demon_lord: 'chr_x' });
  });
});
