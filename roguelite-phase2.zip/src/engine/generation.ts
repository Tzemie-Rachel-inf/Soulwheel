/**
 * The generation loop: the only flow control in character creation, and it holds no
 * content-specific branching at all.
 *
 *   spin → apply modifiers → load nextStepId → repeat until nextStepId is null
 *
 * Which wheel comes next is decided entirely by the winning option's `nextStepId`.
 *
 * How the UI drives it, one spin at a time:
 *   1. outcome = spinCurrentStep(state, config, world, rng)   // winner decided instantly
 *   2. animate the wheel to outcome.roll.winner.index
 *   3. when the animation ends: setState(outcome.state)       // reveal effects, load next wheel
 *
 * The World is read-only during generation. Nothing about the rolling character
 * touches it until `commitCharacter` (see world.ts).
 */
import { applyOption, createCharacter, type CreateCharacterOptions } from './character';
import { EngineError } from './errors';
import { defaultRng, type Rng } from './rng';
import { rollWeightedOption } from './roll';
import type { Character, GameConfig, RollResult, WheelStep, World } from './types';

/** Safety valve for graphs that loop (e.g. a "spin again" option). */
export const MAX_GENERATION_STEPS = 64;

export interface GenerationState {
  character: Character;
  /** The wheel to spin next, or null when generation is finished. */
  currentStepId: string | null;
  stepsTaken: number;
}

export interface SpinOutcome {
  /** The wheel that was spun. */
  step: WheelStep;
  /** All slices plus the pre-calculated winner. */
  roll: RollResult;
  /** The state after applying the winner. Commit it once the animation lands. */
  state: GenerationState;
}

export function startGeneration(config: GameConfig, options?: CreateCharacterOptions): GenerationState {
  return { character: createCharacter(config, options), currentStepId: config.entryStepId, stepsTaken: 0 };
}

export function isGenerationComplete(state: GenerationState): boolean {
  return state.currentStepId === null;
}

/** Look up a wheel by id, failing loudly on a broken link. */
export function getStep(config: GameConfig, stepId: string): WheelStep {
  const step = config.steps[stepId];
  if (!step) throw new EngineError('UNKNOWN_STEP', `No wheel with id "${stepId}".`);
  return step;
}

/** Spin the current wheel once. Pure: the input state is left untouched. */
export function spinCurrentStep(
  state: GenerationState,
  config: GameConfig,
  world: World,
  rng: Rng = defaultRng,
): SpinOutcome {
  if (state.currentStepId === null) {
    throw new EngineError('GENERATION_COMPLETE', 'This character has no wheels left to spin.');
  }
  if (state.stepsTaken >= MAX_GENERATION_STEPS) {
    throw new EngineError(
      'STEP_LIMIT',
      `Generation exceeded ${MAX_GENERATION_STEPS} spins. Check the wheel graph for an unintended loop.`,
    );
  }

  const step = getStep(config, state.currentStepId);
  const roll = rollWeightedOption(step.options, world, state.character, rng);
  const character = applyOption(state.character, roll.winner, step.id, config);

  return {
    step,
    roll,
    state: {
      character,
      currentStepId: roll.winner.option.nextStepId,
      stepsTaken: state.stepsTaken + 1,
    },
  };
}

/**
 * Run the whole loop headlessly. For auto-roll buttons, tests and balance simulations.
 * The returned character is still `rolling`; pass it to `commitCharacter` to place it in the world.
 */
export function rollFullCharacter(
  config: GameConfig,
  world: World,
  rng: Rng = defaultRng,
  options: Omit<CreateCharacterOptions, 'rng'> = {},
): { character: Character; spins: SpinOutcome[] } {
  let state = startGeneration(config, { ...options, rng });
  const spins: SpinOutcome[] = [];

  while (!isGenerationComplete(state)) {
    const outcome = spinCurrentStep(state, config, world, rng);
    spins.push(outcome);
    state = outcome.state;
  }

  return { character: state.character, spins };
}
