import { STAT_KEYS, type Character } from './types';

/** Combat Power per weapon tier, from `CP = stats + weaponTier × 25 + traits`. */
export const WEAPON_TIER_CP = 25;

/** CP split into its three terms, so the Character Card can show where power comes from. */
export interface PowerBreakdown {
  /** Sum of all stats. */
  stats: number;
  /** weaponTier × WEAPON_TIER_CP. */
  weapon: number;
  /** Sum of every trait's `power`. */
  traits: number;
  /** stats + weapon + traits, floored at 0. */
  total: number;
}

export function getPowerBreakdown(char: Character): PowerBreakdown {
  const stats = STAT_KEYS.reduce((sum, key) => sum + char.stats[key], 0);
  const weapon = char.weaponTier * WEAPON_TIER_CP;
  const traits = char.traits.reduce((sum, trait) => sum + trait.power, 0);
  return { stats, weapon, traits, total: Math.max(0, stats + weapon + traits) };
}

/**
 * Combat Power: `(sum of stats) + (weaponTier × 25) + (sum of trait power)`.
 *
 * Derived on demand from what the character rolled, never stored, so it can't go stale.
 */
export function calculatePowerRating(char: Character): number {
  return getPowerBreakdown(char).total;
}

/**
 * The hero's chance to win a fight: `heroCP / (heroCP + bossCP)`.
 *
 * A 100 CP hero against a 300 CP boss wins 25% of the time. Never a flat coin flip.
 * Negative inputs are treated as 0; two 0 CP fighters get an even 50%.
 */
export function calculateWinProbability(heroCP: number, bossCP: number): number {
  const hero = Math.max(0, heroCP);
  const boss = Math.max(0, bossCP);
  return hero + boss === 0 ? 0.5 : hero / (hero + boss);
}
