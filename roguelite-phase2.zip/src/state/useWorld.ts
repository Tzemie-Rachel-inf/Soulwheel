/**
 * The persistent World, kept in React state and mirrored to localStorage.
 *
 * Engine calls that can throw (commitCharacter) run in the event handler, never
 * inside a state updater, so a rejected commit becomes a message instead of a crash.
 */
import { useCallback, useEffect, useState } from 'react';
import { EngineError } from '../engine/errors';
import { loadWorld, saveWorld, type StorageLike } from '../engine/persistence';
import type { Character, World } from '../engine/types';
import { commitCharacter, createWorld } from '../engine/world';

/** localStorage can be missing or throw (private windows, sandboxed frames). Treat that as "no storage". */
function getStorage(): StorageLike | null {
  try {
    const storage = window.localStorage;
    storage.getItem('__probe__');
    return storage;
  } catch {
    return null;
  }
}

export type CommitResult = { ok: true; world: World } | { ok: false; message: string };

export function useWorld() {
  const [world, setWorld] = useState<World>(() => {
    const storage = getStorage();
    return (storage && loadWorld(storage)) ?? createWorld();
  });

  useEffect(() => {
    const storage = getStorage();
    if (!storage) return;
    try {
      saveWorld(world, storage);
    } catch {
      // Quota exceeded or storage revoked: the world keeps running in memory.
    }
  }, [world]);

  /** Place a finished character in the world. Writes any one-of-a-kind roles it claimed. */
  const commit = useCallback(
    (character: Character): CommitResult => {
      try {
        const next = commitCharacter(world, character);
        setWorld(next);
        return { ok: true, world: next };
      } catch (err) {
        const message =
          err instanceof EngineError && err.code === 'SINGLETON_CONFLICT'
            ? 'Someone else claimed one of this character’s one-of-a-kind roles first. Discard and roll again.'
            : err instanceof Error
              ? err.message
              : String(err);
        return { ok: false, message };
      }
    },
    [world],
  );

  const setThreatLevel = useCallback((threatLevel: number) => {
    setWorld((w) => ({ ...w, threatLevel }));
  }, []);

  const resetWorld = useCallback(() => setWorld(createWorld()), []);

  return { world, commit, setThreatLevel, resetWorld };
}
