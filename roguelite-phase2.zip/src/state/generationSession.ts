/**
 * The UI-side flow for rolling one character, as pure functions.
 *
 *   ready ──spin──▶ spinning ──settled──▶ revealing ──advance──▶ ready (next wheel)
 *                                                        └──────▶ complete (nextStepId was null)
 *
 * The winner is decided BEFORE the wheel moves: `startSpin` receives a finished
 * SpinOutcome from the engine. The wheel animation is only presentation, and the
 * character visibly changes only after the wheel lands (`revealing`).
 *
 * Nothing here branches on wheel ids or option ids. It follows `nextStepId`.
 */
import { getStep, startGeneration, type GenerationState, type SpinOutcome } from '../engine/generation';
import { resolveSlices } from '../engine/roll';
import type { CreateCharacterOptions } from '../engine/character';
import type { Character, GameConfig, ResolvedSlice, WheelStep, World } from '../engine/types';

export type GenerationPhase = 'ready' | 'spinning' | 'revealing' | 'complete';

export interface GenerationSession {
  phase: GenerationPhase;
  /** The last state the player has seen applied. */
  state: GenerationState;
  /** A decided spin that is animating (`spinning`) or being shown (`revealing`). */
  pending: SpinOutcome | null;
  /** The most recent spin once applied; lets the finished screen keep showing the last wheel. */
  last: SpinOutcome | null;
  /** Increments with every spin. The wheel uses it to tell spins apart. */
  spinCount: number;
}

export function createSession(config: GameConfig, options?: CreateCharacterOptions): GenerationSession {
  return { phase: 'ready', state: startGeneration(config, options), pending: null, last: null, spinCount: 0 };
}

/** ready → spinning, with the result already known. Ignored in any other phase. */
export function startSpin(session: GenerationSession, outcome: SpinOutcome): GenerationSession {
  if (session.phase !== 'ready') return session;
  return { ...session, phase: 'spinning', pending: outcome, spinCount: session.spinCount + 1 };
}

/** spinning → revealing, once the wheel has stopped. Stale ids (an old spin) are ignored. */
export function settleSpin(session: GenerationSession, spinId: number): GenerationSession {
  if (session.phase !== 'spinning' || spinId !== session.spinCount) return session;
  return { ...session, phase: 'revealing' };
}

/** revealing → ready on the next wheel, or → complete when the graph ends. */
export function advance(session: GenerationSession): GenerationSession {
  if (session.phase !== 'revealing' || !session.pending) return session;
  const state = session.pending.state;
  return {
    ...session,
    phase: state.currentStepId === null ? 'complete' : 'ready',
    state,
    pending: null,
    last: session.pending,
  };
}

export interface SessionView {
  /** The wheel to draw. Null only before any spin on an empty graph. */
  step: WheelStep | null;
  /** Slices to draw. Live odds while ready; frozen at spin time while spinning/revealing. */
  slices: ResolvedSlice[];
  /** The slice the wheel is heading to or has landed on. */
  winnerIndex: number | null;
  /** The character as the player should see it right now. */
  character: Character;
  /** The character before the latest roll, for showing deltas. Null when nothing just changed. */
  previous: Character | null;
  /** True when at least one slice can be rolled. */
  canSpin: boolean;
}

/** Everything the screen needs, derived from the session plus the current world. */
export function viewSession(session: GenerationSession, config: GameConfig, world: World): SessionView {
  const { phase, state, pending, last } = session;

  if (phase === 'ready' && state.currentStepId !== null) {
    const step = getStep(config, state.currentStepId);
    const slices = resolveSlices(step.options, world, state.character);
    return {
      step,
      slices,
      winnerIndex: null,
      character: state.character,
      previous: null,
      canSpin: slices.some((s) => s.effectiveWeight > 0),
    };
  }

  const shown = pending ?? last;
  return {
    step: shown?.step ?? null,
    slices: shown?.roll.slices ?? [],
    winnerIndex: shown?.roll.winner.index ?? null,
    character: phase === 'revealing' && pending ? pending.state.character : state.character,
    previous: phase === 'revealing' ? state.character : null,
    canSpin: false,
  };
}
