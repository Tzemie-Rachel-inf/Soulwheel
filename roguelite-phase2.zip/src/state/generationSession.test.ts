import { describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../config/gameConfig';
import { spinCurrentStep } from '../engine/generation';
import { createSeededRng } from '../engine/rng';
import { commitCharacter, createWorld } from '../engine/world';
import { advance, createSession, settleSpin, startSpin, viewSession, type GenerationSession } from './generationSession';

const world = createWorld({ rng: createSeededRng(1), now: 0 });

function spinOnce(session: GenerationSession, seed: number): GenerationSession {
  const outcome = spinCurrentStep(session.state, GAME_CONFIG, world, createSeededRng(seed));
  return startSpin(session, outcome);
}

describe('generation session', () => {
  it('decides the winner before the wheel moves, but shows it only after landing', () => {
    let s = createSession(GAME_CONFIG, { rng: createSeededRng(2), now: 0 });
    const before = viewSession(s, GAME_CONFIG, world);
    expect(before.canSpin).toBe(true);
    expect(before.winnerIndex).toBeNull();

    s = spinOnce(s, 3);
    const spinning = viewSession(s, GAME_CONFIG, world);
    expect(s.phase).toBe('spinning');
    expect(spinning.winnerIndex).toBe(s.pending?.roll.winner.index ?? -1);
    expect(spinning.character.history).toHaveLength(0); // not revealed yet
    expect(spinning.canSpin).toBe(false);

    s = settleSpin(s, s.spinCount);
    const revealing = viewSession(s, GAME_CONFIG, world);
    expect(s.phase).toBe('revealing');
    expect(revealing.character.history).toHaveLength(1);
    expect(revealing.previous?.history).toHaveLength(0);
  });

  it('ignores a settle from a stale spin', () => {
    const s = spinOnce(createSession(GAME_CONFIG, { now: 0 }), 4);
    expect(settleSpin(s, s.spinCount - 1).phase).toBe('spinning');
  });

  it('follows nextStepId all the way to complete', () => {
    let s = createSession(GAME_CONFIG, { rng: createSeededRng(5), now: 0 });
    let seed = 10;
    while (s.phase !== 'complete') {
      s = spinOnce(s, seed++);
      s = settleSpin(s, s.spinCount);
      s = advance(s);
    }
    const view = viewSession(s, GAME_CONFIG, world);
    expect(s.state.currentStepId).toBeNull();
    expect(view.step?.id).toBe(s.last?.step.id ?? 'missing');
    expect(view.character.history.length).toBeGreaterThan(1);
  });

  it('shows locked slices with live odds while ready', () => {
    let lordWorld = world;
    for (let seed = 0; !lordWorld.activeSingletons['demon_lord']; seed++) {
      let s = createSession(GAME_CONFIG, { rng: createSeededRng(seed), now: 0 });
      while (s.phase !== 'complete') s = advance(settleSpin(spinOnce(s, seed * 31 + s.spinCount), s.spinCount + 1));
      if (s.state.character.role === 'demonLord') lordWorld = commitCharacter(world, s.state.character);
    }
    const view = viewSession(createSession(GAME_CONFIG, { now: 0 }), GAME_CONFIG, lordWorld);
    const lord = view.slices.find((sl) => sl.option.id === 'demon_lord');
    expect(lord?.locked).toBe(true);
    expect(lord?.probability).toBe(0);
  });

  it('refuses to spin twice at once', () => {
    const s = spinOnce(createSession(GAME_CONFIG, { now: 0 }), 6);
    expect(spinOnce(s, 7)).toBe(s);
  });
});
