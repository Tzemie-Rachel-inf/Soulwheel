/**
 * React wrapper around the generation session. The engine call that picks the winner
 * happens here, in the event handler, so state updaters stay pure (StrictMode safe).
 */
import { useCallback, useMemo, useState } from 'react';
import { generateName } from '../config/names';
import { EngineError } from '../engine/errors';
import { spinCurrentStep } from '../engine/generation';
import type { GameConfig, World } from '../engine/types';
import type { SpinRequest } from '../ui/wheel/SpinWheel';
import { advance, createSession, settleSpin, startSpin, viewSession } from './generationSession';

function freshSession(config: GameConfig) {
  return createSession(config, { name: generateName() });
}

export function useCharacterGeneration(config: GameConfig, world: World) {
  const [session, setSession] = useState(() => freshSession(config));
  const [error, setError] = useState<string | null>(null);

  const view = useMemo(() => viewSession(session, config, world), [session, config, world]);

  /** The request the wheel animates. Same object for the whole spin, a new one per spin. */
  const pending = session.pending;
  const spinRequest = useMemo<SpinRequest | null>(
    () =>
      session.phase === 'spinning' && pending
        ? { id: session.spinCount, targetIndex: pending.roll.winner.index }
        : null,
    [session.phase, session.spinCount, pending],
  );

  const spin = useCallback(() => {
    if (session.phase !== 'ready') return;
    try {
      const outcome = spinCurrentStep(session.state, config, world);
      setError(null);
      setSession((s) => startSpin(s, outcome));
    } catch (err) {
      setError(
        err instanceof EngineError && err.code === 'NO_ELIGIBLE_OPTIONS'
          ? 'Every slice on this wheel is locked. Change the world, or give this wheel an option with no conditions.'
          : err instanceof Error
            ? err.message
            : String(err),
      );
    }
  }, [session, config, world]);

  const settle = useCallback((spinId: number) => setSession((s) => settleSpin(s, spinId)), []);
  const next = useCallback(() => setSession(advance), []);
  const restart = useCallback(() => {
    setError(null);
    setSession(freshSession(config));
  }, [config]);

  return { session, view, spinRequest, error, spin, settle, next, restart };
}
