/** Name pools for freshly rolled souls. Content, not engine: edit freely. */
import type { Rng } from '../engine/rng';

const GIVEN = [
  'Aldric', 'Brenna', 'Caius', 'Doran', 'Elowen', 'Fenna', 'Garrick', 'Halvard', 'Isolde', 'Joran',
  'Kestra', 'Lucan', 'Mirela', 'Nyx', 'Orin', 'Perrin', 'Quillon', 'Rowan', 'Seren', 'Talia',
  'Ulric', 'Vesna', 'Wren', 'Yorick', 'Zara', 'Ambrose', 'Brannoc', 'Cressida', 'Edda', 'Thane',
];

const EPITHETS = [
  'of Ashfall', 'the Unbowed', 'of the Grey March', 'Thornwood', 'the Lantern-Bearer', 'of Mournvale',
  'of Hollow Fen', 'the Quiet', 'Stormborn', 'of the Last Light', 'Saltmarsh', 'the Twice-Buried',
  'of Cinder Reach', 'Oathless', 'the Late Bloom',
];

const pick = <T>(items: readonly T[], rng: Rng): T => items[Math.floor(rng() * items.length)] ?? items[0]!;

export function generateName(rng: Rng = Math.random): string {
  return `${pick(GIVEN, rng)} ${pick(EPITHETS, rng)}`;
}
