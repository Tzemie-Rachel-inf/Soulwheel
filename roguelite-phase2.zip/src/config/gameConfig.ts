/**
 * Sample content: four connected wheels.
 *
 *          ┌─▶ Wheel of Talents ──▶ The Armory ──▶ end
 *          │         └─ (Holy Sword skips the Armory) ──▶ end
 *   Fate ──┤
 *          └─▶ Abyssal Wheel (Demon Lord only) ──▶ end
 *
 * Everything here is data. To add a wheel: write a WheelStep, register it in
 * `steps`, and point some option's `nextStepId` at it. To add a one-of-a-kind role:
 * give an option `claimSingleton: 'any_new_key'`. Neither touches engine or UI code.
 *
 * Rules demonstrated:
 *  - One-of-a-kind roles:  Demon Lord, Holy Sword bearer, Archmage (three keys, zero engine code).
 *  - World conditions:     Echoes of the Fallen, Heirloom, Lich King need souls in the graveyard.
 *  - Character conditions: Arcane Savant and Archmage need Arcana from a lucky Fate roll.
 *  - Cross-rule:           the Holy Sword wakes only while a Demon Lord reigns, and rejects cursed blood.
 *  - Threat scaling:       darkness grows likelier as threatLevel rises; blessings fade.
 */
import { isSingletonClaimed } from '../engine/world';
import type { GameConfig, StatBlock, Trait, WheelStep } from '../engine/types';

/**
 * The one-of-a-kind roles used by this config. The engine accepts any string;
 * these constants only exist so conditions and options can't drift apart by typo.
 */
export const SINGLETON = {
  demonLord: 'demon_lord',
  holySwordBearer: 'holy_sword_bearer',
  archmage: 'archmage',
} as const;

const BASE_STATS: StatBlock = { might: 10, agility: 10, intellect: 10, arcana: 10, vitality: 10 };

const TRAITS = {
  // Fate
  divine_favor: { id: 'divine_favor', name: 'Divine Favor', description: 'The gods watch over this soul.', power: 40 },
  cursed_blood: { id: 'cursed_blood', name: 'Cursed Blood', description: 'Power with a price. Holy relics refuse you.', power: 20 },
  demon_lord_mantle: { id: 'demon_lord_mantle', name: 'Mantle of the Demon Lord', description: 'Sovereign of the abyss. There can be only one.', power: 150 },
  // Talents
  blademaster: { id: 'blademaster', name: 'Blademaster', description: 'Any weapon fights a tier above its make.', power: 25 },
  arcane_savant: { id: 'arcane_savant', name: 'Arcane Savant', description: 'Reads spells the way others read signs.', power: 35 },
  iron_will: { id: 'iron_will', name: 'Iron Will', description: 'Gets back up. Every time.', power: 20 },
  shadowstep: { id: 'shadowstep', name: 'Shadowstep', description: 'Strikes from where no one is standing.', power: 25 },
  ancestral_echoes: { id: 'ancestral_echoes', name: 'Echoes of the Fallen', description: 'Guided by heroes who died before.', power: 45 },
  holy_sword: { id: 'holy_sword', name: 'Holy Sword Bearer', description: 'Chosen to end the Demon Lord’s reign.', power: 60 },
  archmage: { id: 'archmage', name: 'Archmage of the Spire', description: 'The tower answers to one mage at a time.', power: 70 },
  // Armory
  dragonbone: { id: 'dragonbone', name: 'Dragonbone', description: 'The blade remembers the dragon it came from.', power: 20 },
  // Abyssal
  infernal_tyrant: { id: 'infernal_tyrant', name: 'Infernal Tyrant', description: 'Rules by fire and fear.', power: 40 },
  plague_sovereign: { id: 'plague_sovereign', name: 'Plague Sovereign', description: 'Every breath of the world is borrowed.', power: 35 },
  void_herald: { id: 'void_herald', name: 'Void Herald', description: 'Speaks for the space between stars.', power: 45 },
  lich_phylactery: { id: 'lich_phylactery', name: 'Phylactery', description: 'Bound to the souls of the graveyard.', power: 90 },
} satisfies Record<string, Trait>;

// ─── Wheel 1: Fate ──────────────────────────────────────────────────────────

const FATE: WheelStep = {
  id: 'fate',
  title: 'Wheel of Fate',
  subtitle: 'Every soul begins here.',
  options: [
    {
      id: 'normal_fate',
      label: 'Normal Fate',
      description: 'An ordinary birth. Your story is yours to write.',
      baseWeight: 50,
      nextStepId: 'talents',
      color: '#64748b',
      icon: 'Footprints',
    },
    {
      id: 'blessed',
      label: 'Blessed by the Gods',
      description: 'Born under a favourable sky.',
      baseWeight: 14,
      threatScaling: -0.1, // the gods withdraw as the world darkens
      statModifiers: { might: 2, agility: 2, intellect: 3, arcana: 3, vitality: 2 },
      grantTraits: ['divine_favor'],
      grantTags: ['blessed'],
      nextStepId: 'talents',
      color: '#f59e0b',
      icon: 'Sun',
    },
    {
      id: 'cursed',
      label: 'Cursed Birth',
      description: 'Strength, bought with something you never agreed to sell.',
      baseWeight: 14,
      threatScaling: 0.25,
      statModifiers: { might: 4, arcana: 2, vitality: -3 },
      grantTraits: ['cursed_blood'],
      grantTags: ['cursed'],
      nextStepId: 'talents',
      color: '#8b5cf6',
      icon: 'Skull',
    },
    {
      id: 'demon_lord',
      label: 'Demon Lord',
      description: 'You are the darkness the heroes are born to fight.',
      baseWeight: 6,
      threatScaling: 0.2,
      // A one-of-a-kind role. No `condition` needed: the engine locks this slice
      // whenever 'demon_lord' is a key in world.activeSingletons.
      claimSingleton: SINGLETON.demonLord,
      lockedReason: 'A Demon Lord already reigns over this world',
      setRole: 'demonLord',
      statModifiers: { might: 15, arcana: 15, vitality: 20 },
      grantTraits: ['demon_lord_mantle'],
      grantTags: ['demonic'],
      nextStepId: 'abyssal',
      color: '#dc2626',
      icon: 'Crown',
    },
  ],
};

// ─── Wheel 2: Talents (heroes) ──────────────────────────────────────────────

const TALENTS: WheelStep = {
  id: 'talents',
  title: 'Wheel of Talents',
  subtitle: 'What gift did fate leave you?',
  options: [
    {
      id: 'blademaster',
      label: 'Blademaster',
      description: 'Steel answers to you.',
      baseWeight: 25,
      statModifiers: { might: 3, agility: 2 },
      weaponTierDelta: 1, // mastery: whatever the Armory gives, it hits a tier harder
      grantTraits: ['blademaster'],
      nextStepId: 'armory',
      color: '#e11d48',
      icon: 'Swords',
    },
    {
      id: 'arcane_savant',
      label: 'Arcane Savant',
      description: 'The weave of magic is plain to you.',
      baseWeight: 18,
      statModifiers: { intellect: 3, arcana: 5 },
      grantTraits: ['arcane_savant'],
      condition: (_world, char) => char.stats.arcana >= 12,
      lockedReason: (_world, char) => `Requires 12 Arcana (you have ${char.stats.arcana})`,
      nextStepId: 'armory',
      color: '#6366f1',
      icon: 'Sparkles',
    },
    {
      id: 'unbreakable',
      label: 'Unbreakable',
      description: 'Pain is information, nothing more.',
      baseWeight: 25,
      statModifiers: { vitality: 5, might: 1 },
      grantTraits: ['iron_will'],
      nextStepId: 'armory',
      color: '#0d9488',
      icon: 'Shield',
    },
    {
      id: 'shadowstep',
      label: 'Shadowstep',
      description: 'Gone before the guard turns around.',
      baseWeight: 20,
      statModifiers: { agility: 5 },
      grantTraits: ['shadowstep'],
      nextStepId: 'armory',
      color: '#86198f',
      icon: 'Wind',
    },
    {
      id: 'echoes',
      label: 'Echoes of the Fallen',
      description: 'The dead lend you what they learned.',
      baseWeight: 12,
      statModifiers: { intellect: 2, vitality: 2 },
      grantTraits: ['ancestral_echoes'],
      condition: (world) => world.graveyard.length >= 3,
      lockedReason: (world) => `Requires 3 souls in the graveyard (${world.graveyard.length}/3)`,
      nextStepId: 'armory',
      color: '#0891b2',
      icon: 'Ghost',
    },
    {
      id: 'archmage',
      label: 'Archmage of the Spire',
      description: 'The tower has waited for you.',
      baseWeight: 6,
      // A third one-of-a-kind role, added with zero engine changes.
      claimSingleton: SINGLETON.archmage,
      condition: (_world, char) => char.stats.arcana >= 13,
      lockedReason: (world, char) =>
        isSingletonClaimed(world, SINGLETON.archmage)
          ? 'The Spire already has its Archmage'
          : `Requires 13 Arcana (you have ${char.stats.arcana})`,
      statModifiers: { intellect: 4, arcana: 8 },
      grantTraits: ['archmage'],
      nextStepId: 'armory',
      color: '#2563eb',
      icon: 'Gem',
    },
    {
      id: 'holy_sword',
      label: 'Chosen of the Holy Sword',
      description: 'The blade picked you. It does not explain itself.',
      baseWeight: 5,
      threatScaling: 0.5, // rises to meet the darkness
      claimSingleton: SINGLETON.holySwordBearer,
      condition: (world, char) => isSingletonClaimed(world, SINGLETON.demonLord) && !char.tags.includes('cursed'),
      lockedReason: (world, char) => {
        if (isSingletonClaimed(world, SINGLETON.holySwordBearer)) return 'The Holy Sword has already chosen a bearer';
        if (char.tags.includes('cursed')) return 'The Holy Sword rejects cursed blood';
        return 'The Holy Sword sleeps until a Demon Lord rises';
      },
      weaponTierDelta: 5,
      grantTraits: ['holy_sword'],
      nextStepId: null, // already armed: skips the Armory
      color: '#facc15',
      icon: 'Sword',
    },
  ],
};

// ─── Wheel 3: The Armory (heroes) ───────────────────────────────────────────

const ARMORY: WheelStep = {
  id: 'armory',
  title: 'The Armory',
  subtitle: 'Every legend needs something to swing.',
  options: [
    {
      id: 'empty_hands',
      label: 'Empty Hands',
      description: 'Nothing but fists and nerve.',
      baseWeight: 8,
      statModifiers: { agility: 2 },
      nextStepId: null,
      color: '#6b7280',
      icon: 'Hand',
    },
    {
      id: 'rusted_shortsword',
      label: 'Rusted Shortsword',
      description: 'It has seen better centuries.',
      baseWeight: 28,
      weaponTierDelta: 1,
      nextStepId: null,
      color: '#a16207',
      icon: 'Slice',
    },
    {
      id: 'hunters_longbow',
      label: 'Hunter’s Longbow',
      description: 'Patience, strung and waxed.',
      baseWeight: 22,
      weaponTierDelta: 2,
      statModifiers: { agility: 2 },
      nextStepId: null,
      color: '#15803d',
      icon: 'Target',
    },
    {
      id: 'runed_staff',
      label: 'Runed Staff',
      description: 'Warm to the touch, and humming.',
      baseWeight: 16,
      weaponTierDelta: 2,
      statModifiers: { arcana: 3 },
      nextStepId: null,
      color: '#7c3aed',
      icon: 'WandSparkles',
    },
    {
      id: 'war_axe',
      label: 'Dwarven War Axe',
      description: 'Heavy enough to settle arguments.',
      baseWeight: 16,
      weaponTierDelta: 3,
      statModifiers: { might: 3 },
      nextStepId: null,
      color: '#b45309',
      icon: 'Axe',
    },
    {
      id: 'fallen_heirloom',
      label: 'Heirloom of the Fallen',
      description: 'Taken up from a hero who will not need it again.',
      baseWeight: 8,
      weaponTierDelta: 4,
      condition: (world) => world.graveyard.length >= 1,
      lockedReason: 'No hero has fallen yet',
      nextStepId: null,
      color: '#0e7490',
      icon: 'Medal',
    },
    {
      id: 'dragonbone_blade',
      label: 'Dragonbone Blade',
      description: 'Carved from the last of the old wyrms.',
      baseWeight: 2,
      threatScaling: 0.3,
      weaponTierDelta: 5,
      grantTraits: ['dragonbone'],
      nextStepId: null,
      color: '#d6cfb8',
      icon: 'Bone',
    },
  ],
};

// ─── Wheel 4: Abyssal (Demon Lord only) ─────────────────────────────────────

const ABYSSAL: WheelStep = {
  id: 'abyssal',
  title: 'Abyssal Wheel',
  subtitle: 'What manner of darkness do you rule?',
  options: [
    {
      id: 'infernal_tyrant',
      label: 'Infernal Tyrant',
      description: 'The world will burn on your schedule.',
      baseWeight: 35,
      statModifiers: { might: 10, vitality: 5 },
      weaponTierDelta: 3,
      grantTraits: ['infernal_tyrant'],
      nextStepId: null,
      color: '#b91c1c',
      icon: 'Flame',
    },
    {
      id: 'plague_sovereign',
      label: 'Plague Sovereign',
      description: 'Your court coughs in unison.',
      baseWeight: 30,
      statModifiers: { arcana: 8, vitality: 4 },
      weaponTierDelta: 2,
      grantTraits: ['plague_sovereign'],
      nextStepId: null,
      color: '#65a30d',
      icon: 'Biohazard',
    },
    {
      id: 'void_herald',
      label: 'Void Herald',
      description: 'Something vast speaks through you.',
      baseWeight: 25,
      statModifiers: { agility: 6, arcana: 6 },
      weaponTierDelta: 2,
      grantTraits: ['void_herald'],
      nextStepId: null,
      color: '#4c1d95',
      icon: 'Orbit',
    },
    {
      id: 'lich_king',
      label: 'Lich King',
      description: 'Death was a door, and you kept the key.',
      baseWeight: 10,
      threatScaling: 0.3,
      statModifiers: { arcana: 12, intellect: 6 },
      weaponTierDelta: 2,
      grantTraits: ['lich_phylactery'],
      condition: (world) => world.graveyard.length >= 5,
      lockedReason: (world) => `Requires 5 souls in the graveyard (${world.graveyard.length}/5)`,
      nextStepId: null,
      color: '#0f766e',
      icon: 'Skull',
    },
  ],
};

// ─── Assembled config ───────────────────────────────────────────────────────

export const GAME_CONFIG: GameConfig = {
  entryStepId: 'fate',
  steps: {
    [FATE.id]: FATE,
    [TALENTS.id]: TALENTS,
    [ARMORY.id]: ARMORY,
    [ABYSSAL.id]: ABYSSAL,
  },
  traits: TRAITS,
  baseStats: BASE_STATS,
};
