import { describe, expect, it } from 'vitest';
import { createSeededRng } from '../../engine/rng';
import {
  boundaryCount,
  mod,
  screenAngleOf,
  sliceAtPointer,
  sliceAtScreenAngle,
  sliceCenterAngle,
  spinEase,
  targetRotation,
} from './wheelGeometry';

describe('targetRotation', () => {
  it('always lands the chosen slice under the pointer', () => {
    const rng = createSeededRng(9);
    for (let trial = 0; trial < 5_000; trial++) {
      const count = 2 + Math.floor(rng() * 11);
      const index = Math.floor(rng() * count);
      const from = (rng() - 0.5) * 10_000;
      const to = targetRotation(from, index, count, { turns: 1 + Math.floor(rng() * 7), offset: rng() });
      expect(sliceAtPointer(to, count)).toBe(index);
    }
  });

  it('only ever spins forward, by at least the requested turns', () => {
    const to = targetRotation(123, 2, 6, { turns: 5 });
    expect(to - 123).toBeGreaterThan(5 * 360 - 1);
    expect(to - 123).toBeLessThan(6 * 360);
  });

  it('never stops on a lead line, even at extreme offsets', () => {
    const count = 7;
    const a = 360 / count;
    for (const offset of [0, 1, -3, 9]) {
      const to = targetRotation(0, 3, count, { offset });
      const intoSlice = mod(-to, 360) - 3 * a;
      expect(intoSlice).toBeGreaterThan(a * 0.149);
      expect(intoSlice).toBeLessThan(a * 0.851);
    }
  });
});

describe('hit testing', () => {
  it('finds the slice under a screen point at any rotation', () => {
    // 4 slices, unrotated: slice 1 spans 90°–180° (3 o'clock to 6 o'clock).
    expect(sliceAtScreenAngle(screenAngleOf(10, 10), 0, 4)).toBe(1);
    // Rotate a quarter turn clockwise: slice 0 now sits on the right-bottom quadrant.
    expect(sliceAtScreenAngle(screenAngleOf(10, 10), 90, 4)).toBe(0);
  });

  it('measures screen angles clockwise from 12 o’clock', () => {
    expect(screenAngleOf(0, -1)).toBeCloseTo(0, 6);
    expect(screenAngleOf(1, 0)).toBeCloseTo(90, 6);
    expect(screenAngleOf(0, 1)).toBeCloseTo(180, 6);
    expect(screenAngleOf(-1, 0)).toBeCloseTo(270, 6);
  });

  it('puts slice centres where the pointer expects them', () => {
    expect(sliceAtPointer(-sliceCenterAngle(4, 6), 6)).toBe(4);
  });
});

describe('animation helpers', () => {
  it('eases from 0 to 1 and clamps', () => {
    expect(spinEase(0)).toBe(0);
    expect(spinEase(1)).toBe(1);
    expect(spinEase(2)).toBe(1);
    expect(spinEase(0.5)).toBeGreaterThan(0.9); // most of the travel happens early
  });

  it('counts one boundary per slice passed', () => {
    expect(boundaryCount(359, 6)).toBe(5);
    expect(boundaryCount(360, 6)).toBe(6);
    expect(boundaryCount(720 + 61, 6)).toBe(13);
  });
});
