/**
 * The spinning rose window.
 *
 * It never decides anything. The engine has already picked the winner
 * (`spin.targetIndex`); this component works out a stopping angle inside that slice
 * and animates there, with a requestAnimationFrame loop that also drives the pointer tick.
 *
 * Layers, back to front:
 *   rotor   – the painted canvas plus Lucide icons; the only thing that rotates
 *   sheen   – a static highlight, so the glass turns under fixed "daylight"
 *   hub     – the Spin button, which stays still
 *   pointer – gilt finial at 12 o'clock that flicks as each lead line passes
 */
import { useCallback, useEffect, useLayoutEffect, useRef, useState, type PointerEvent } from 'react';
import { useReducedMotion } from 'framer-motion';
import { Lock } from 'lucide-react';
import type { ResolvedSlice } from '../../engine/types';
import { formatPercent } from '../format';
import { getOptionIcon } from '../icons';
import { inkFor } from './color';
import { glassColor, paintWheel } from './paintWheel';
import {
  WHEEL_LAYOUT as L,
  boundaryCount,
  polar,
  screenAngleOf,
  sliceAngle,
  sliceAtScreenAngle,
  sliceCenterAngle,
  spinEase,
  targetRotation,
} from './wheelGeometry';

export interface SpinRequest {
  /** Changes for every spin. */
  id: number;
  /** The slice the engine picked. */
  targetIndex: number;
}

export interface SpinWheelProps {
  slices: readonly ResolvedSlice[];
  /** Set to start a spin. Must keep the same identity until the next spin. */
  spin: SpinRequest | null;
  /** Lit up after landing; every other slice dims. */
  highlightIndex: number | null;
  canSpin: boolean;
  onSpinRequest: () => void;
  /** Called once the wheel has come to rest on the target. */
  onSettled: (spinId: number) => void;
  /** Accessible name for the wheel, e.g. its title. */
  label: string;
  hubLabel?: string;
  maxSize?: number;
  fontFamily?: string;
}

const SPIN_MS = 5200;
const REDUCED_SPIN_MS = 900;
const DEFAULT_FONT = '"Alegreya Sans", ui-sans-serif, system-ui, sans-serif';

export function SpinWheel({
  slices,
  spin,
  highlightIndex,
  canSpin,
  onSpinRequest,
  onSettled,
  label,
  hubLabel = 'Spin',
  maxSize = 560,
  fontFamily = DEFAULT_FONT,
}: SpinWheelProps) {
  const frameRef = useRef<HTMLDivElement>(null);
  const rotorRef = useRef<HTMLDivElement>(null);
  const pointerRef = useRef<SVGSVGElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rotationRef = useRef(0);
  const spinningRef = useRef(false);
  const onSettledRef = useRef(onSettled);
  const reduceMotion = useReducedMotion() ?? false;

  const [size, setSize] = useState(0);
  const [fontEpoch, setFontEpoch] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [hover, setHover] = useState<{ index: number; x: number; y: number } | null>(null);

  useEffect(() => {
    onSettledRef.current = onSettled;
  }, [onSettled]);

  // Size to the container, capped.
  useLayoutEffect(() => {
    const el = frameRef.current;
    if (!el) return;
    const measure = () => setSize(Math.floor(Math.min(el.clientWidth, maxSize)));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [maxSize]);

  // Repaint once web fonts arrive, so labels are measured in the real face.
  useEffect(() => {
    let alive = true;
    const bump = () => {
      if (alive) setFontEpoch((n) => n + 1);
    };
    void document.fonts.ready.then(bump);
    document.fonts.addEventListener('loadingdone', bump);
    return () => {
      alive = false;
      document.fonts.removeEventListener('loadingdone', bump);
    };
  }, []);

  // Paint the static face whenever what it shows changes. Never per frame.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || size === 0) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    canvas.width = Math.round(size * dpr);
    canvas.height = Math.round(size * dpr);
    const ctx = canvas.getContext('2d');
    if (ctx) paintWheel(ctx, { size, dpr, slices, highlightIndex, fontFamily });
  }, [size, slices, highlightIndex, fontFamily, fontEpoch]);

  const applyRotation = useCallback((degrees: number) => {
    rotationRef.current = degrees;
    if (rotorRef.current) rotorRef.current.style.transform = `rotate(${degrees}deg)`;
  }, []);

  // Each new wheel starts with its first slice centred under the pointer, never on a lead line.
  // A landed wheel keeps its resting angle until a different wheel replaces it.
  const wheelKey = slices.map((s) => s.option.id).join('|');
  const mounted = size > 0;
  useLayoutEffect(() => {
    if (!mounted || spinningRef.current || slices.length === 0) return;
    applyRotation(Math.round(rotationRef.current / 360) * 360 - sliceAngle(slices.length) / 2);
  }, [wheelKey, mounted, slices.length, applyRotation]);

  // The spin itself: ease from the current angle to a pre-calculated stop.
  useEffect(() => {
    if (!spin) return;
    const count = slices.length;
    const from = rotationRef.current;
    const duration = reduceMotion ? REDUCED_SPIN_MS : SPIN_MS;
    const to = targetRotation(from, spin.targetIndex, count, {
      turns: reduceMotion ? 1 : 5 + Math.floor(Math.random() * 3),
      offset: 0.2 + Math.random() * 0.6, // land somewhere inside the slice, never on a lead line
    });

    let raf = 0;
    let startedAt: number | null = null;
    let lastBoundary = boundaryCount(from, count);
    let tickAt = Number.NEGATIVE_INFINITY;
    spinningRef.current = true;
    setSpinning(true);
    setHover(null);

    const frame = (now: number) => {
      startedAt ??= now;
      const t = (now - startedAt) / duration;
      const rotation = from + (to - from) * spinEase(t);
      applyRotation(rotation);

      const boundary = boundaryCount(rotation, count);
      if (boundary !== lastBoundary) {
        lastBoundary = boundary;
        tickAt = now;
      }
      if (pointerRef.current) {
        const kick = Math.exp(-(now - tickAt) / 90);
        pointerRef.current.style.transform = `rotate(${(-22 * kick).toFixed(2)}deg)`;
      }

      if (t < 1) {
        raf = requestAnimationFrame(frame);
        return;
      }
      applyRotation(to);
      if (pointerRef.current) pointerRef.current.style.transform = 'rotate(0deg)';
      spinningRef.current = false;
      setSpinning(false);
      onSettledRef.current(spin.id);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      spinningRef.current = false;
    };
  }, [spin, slices.length, reduceMotion, applyRotation]);

  const handlePointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (spinningRef.current || size === 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const dx = e.clientX - rect.left - rect.width / 2;
    const dy = e.clientY - rect.top - rect.height / 2;
    const r = Math.hypot(dx, dy) / (size / 2);
    if (r < L.hub || r > L.glassEdge) {
      setHover(null);
      return;
    }
    const index = sliceAtScreenAngle(screenAngleOf(dx, dy), rotationRef.current, slices.length);
    setHover({ index, x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  const R = size / 2;
  const hubSize = R * L.hub * 2 - 6;
  const iconSize = Math.max(14, R * L.roundelRadius * 1.15);
  const hovered = hover ? slices[hover.index] : undefined;

  return (
    <div
      ref={frameRef}
      role="group"
      aria-label={label}
      className="relative mx-auto w-full select-none"
      style={{ maxWidth: maxSize, height: size || undefined }}
    >
      {size > 0 && (
        <>
          <div
            className="absolute inset-0 rounded-full"
            onPointerMove={handlePointerMove}
            onPointerLeave={() => setHover(null)}
          >
            <div ref={rotorRef} className="absolute inset-0" style={{ willChange: 'transform' }}>
              <canvas ref={canvasRef} aria-hidden="true" className="absolute inset-0 h-full w-full" />
              {slices.map((slice, i) => {
                const angle = sliceCenterAngle(i, slices.length);
                const p = polar(R * L.roundel, angle);
                const Icon = slice.locked ? Lock : getOptionIcon(slice.option.icon);
                const dimmed = highlightIndex !== null && highlightIndex !== i;
                return (
                  <Icon
                    key={slice.option.id}
                    aria-hidden="true"
                    size={iconSize}
                    strokeWidth={2.25}
                    className="pointer-events-none absolute transition-opacity duration-500"
                    style={{
                      left: R + p.x - iconSize / 2,
                      top: R + p.y - iconSize / 2,
                      transform: `rotate(${angle}deg)`,
                      color: inkFor(glassColor(slice)).ink,
                      opacity: dimmed ? 0.35 : slice.locked ? 0.75 : 1,
                    }}
                  />
                );
              })}
            </div>
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 rounded-full"
              style={{
                background:
                  'radial-gradient(circle at 32% 24%, rgba(255, 249, 232, 0.18), rgba(255, 249, 232, 0) 46%)',
              }}
            />
          </div>

          <button
            type="button"
            onClick={onSpinRequest}
            disabled={!canSpin || spinning}
            className="font-display absolute z-10 flex items-center justify-center rounded-full border-[3px] border-lead text-candle transition-[filter,color] duration-200 enabled:hover:brightness-125 disabled:cursor-not-allowed disabled:text-candle/35"
            style={{
              width: hubSize,
              height: hubSize,
              left: R - hubSize / 2,
              top: R - hubSize / 2,
              fontSize: Math.max(18, R * 0.115),
              background: 'radial-gradient(circle at 40% 32%, #4a5269, #262c3d 62%, #1a1e2b)',
              boxShadow: 'inset 0 0 0 2px rgba(201, 162, 76, 0.85), inset 0 -6px 12px rgba(0, 0, 0, 0.35)',
            }}
          >
            {hubLabel}
          </button>

          <svg
            ref={pointerRef}
            aria-hidden="true"
            viewBox="0 0 40 56"
            className="pointer-events-none absolute z-20"
            style={{
              width: R * 0.15,
              height: R * 0.21,
              left: R - R * 0.075,
              top: -R * 0.05,
              transformOrigin: '50% 27%',
              filter: 'drop-shadow(0 3px 3px rgba(0, 0, 0, 0.5))',
            }}
          >
            <defs>
              <linearGradient id="wheel-pointer-gilt" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#f5e0a6" />
                <stop offset="0.55" stopColor="#c9a24c" />
                <stop offset="1" stopColor="#7d5f20" />
              </linearGradient>
            </defs>
            <path
              d="M20 54 L6.5 22 A14 14 0 1 1 33.5 22 Z"
              fill="url(#wheel-pointer-gilt)"
              stroke="#0b0e16"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            <circle cx="20" cy="15" r="4.5" fill="#0b0e16" />
          </svg>

          {hover && hovered && (
            <div
              role="tooltip"
              className="pointer-events-none absolute z-30 w-max max-w-56 rounded-md border-2 border-lead bg-slab-raised px-3 py-2 text-sm shadow-lg"
              style={{
                left: Math.min(Math.max(hover.x + 14, 8), size - 200),
                top: Math.max(hover.y - 52, 4),
              }}
            >
              <p className="font-semibold text-candle">{hovered.option.label}</p>
              <p className="text-ash">
                {hovered.locked ? hovered.lockReason : `${formatPercent(hovered.probability)} chance`}
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
