/**
 * Pure wheel math. No DOM, no React: unit-tested on its own.
 *
 * Conventions used everywhere in the wheel:
 *  - Angles are degrees, measured clockwise from 12 o'clock (where the pointer sits).
 *  - "Wheel space" is the wheel's own frame. Slice i spans [i·a, (i+1)·a), a = 360 / count.
 *  - `rotation` is the CSS rotation applied to the wheel, clockwise-positive. A point at
 *    wheel-space angle θ appears on screen at θ + rotation.
 *  - Slices are all the same size (a design decision: every option stays visible).
 *    True odds are shown in the odds list, not by slice width.
 */

/** Radii as fractions of the wheel radius. Shared by the painter and the DOM overlays. */
export const WHEEL_LAYOUT = {
  /** The static Spin button in the middle. */
  hub: 0.22,
  /** Labels sit between these two radii. */
  labelInner: 0.36,
  labelOuter: 0.67,
  /** Lead-line arc splitting each pane into inner and outer glass. */
  tracery: 0.71,
  /** Icon roundel: centre radius and the roundel's own radius. */
  roundel: 0.815,
  roundelRadius: 0.085,
  /** Where the glass ends and the stone rim begins. */
  glassEdge: 0.915,
} as const;

/** Euclidean modulo: always in [0, n). */
export function mod(value: number, n: number): number {
  return ((value % n) + n) % n;
}

export function sliceAngle(count: number): number {
  return 360 / count;
}

/** Wheel-space angle of a slice's centre line. */
export function sliceCenterAngle(index: number, count: number): number {
  return (index + 0.5) * sliceAngle(count);
}

/**
 * Which slice is at a given screen angle when the wheel is rotated by `rotation`.
 * Screen angle 0 is the pointer.
 */
export function sliceAtScreenAngle(screenAngle: number, rotation: number, count: number): number {
  const wheelAngle = mod(screenAngle - rotation, 360);
  return Math.min(count - 1, Math.floor(wheelAngle / sliceAngle(count)));
}

/** Which slice the pointer is on. */
export function sliceAtPointer(rotation: number, count: number): number {
  return sliceAtScreenAngle(0, rotation, count);
}

/** Screen angle (clockwise from 12 o'clock) of a point relative to the wheel's centre. */
export function screenAngleOf(dx: number, dy: number): number {
  return mod((Math.atan2(dx, -dy) * 180) / Math.PI, 360);
}

export interface SpinTargetOptions {
  /** Whole turns before landing. More turns = more drama. */
  turns?: number;
  /**
   * Where inside the slice to stop, 0–1 (0.5 = dead centre). Clamped to [0.15, 0.85]
   * so the wheel never comes to rest on a lead line, where the result would look ambiguous.
   */
  offset?: number;
}

/**
 * The rotation that puts slice `index` under the pointer, travelling clockwise from
 * `from` through at least `turns` full turns.
 *
 * This is how the wheel "animates to a pre-calculated result": the engine has already
 * picked `index`; this only works out where to stop.
 */
export function targetRotation(
  from: number,
  index: number,
  count: number,
  { turns = 6, offset = 0.5 }: SpinTargetOptions = {},
): number {
  const landing = (index + clamp(offset, 0.15, 0.85)) * sliceAngle(count);
  const desired = mod(-landing, 360);
  const delta = mod(desired - mod(from, 360), 360);
  return from + turns * 360 + delta;
}

/**
 * Prize-wheel deceleration: quick release, then a long slow crawl so the last
 * few slices tick past one by one.
 */
export function spinEase(t: number): number {
  const c = clamp(t, 0, 1);
  return 1 - (1 - c) ** 4;
}

/**
 * Counts slice boundaries crossed under the pointer. The pointer "ticks" whenever this
 * number changes. Boundaries sit at every multiple of the slice angle.
 */
export function boundaryCount(rotation: number, count: number): number {
  return Math.floor(rotation / sliceAngle(count));
}

/** Converts a wheel angle (clockwise from 12) to a canvas angle in radians (clockwise from 3 o'clock). */
export function toCanvasRadians(degrees: number): number {
  return ((degrees - 90) * Math.PI) / 180;
}

/** Point on the wheel at a radius and wheel-space angle, relative to the centre (screen y points down). */
export function polar(radius: number, degrees: number): { x: number; y: number } {
  const rad = (degrees * Math.PI) / 180;
  return { x: radius * Math.sin(rad), y: -radius * Math.cos(rad) };
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
