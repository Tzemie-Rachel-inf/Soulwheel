/**
 * Paints the static wheel face: a rose window of stained-glass panes.
 *
 * The canvas is painted once per change (slices, size, highlight, fonts), never per
 * frame. Spinning is a CSS rotation of the finished canvas, which keeps the animation
 * on the GPU and the painter simple.
 *
 * Locked slices are painted as boarded-up grey glass. They keep their full size:
 * every option stays visible, only its odds drop to zero.
 */
import { createSeededRng } from '../../engine/rng';
import type { ResolvedSlice } from '../../engine/types';
import { darken, inkFor, lighten, mix, withAlpha } from './color';
import { WHEEL_LAYOUT as L, sliceAngle, toCanvasRadians } from './wheelGeometry';

export interface PaintWheelOptions {
  /** Width and height in CSS pixels. */
  size: number;
  /** devicePixelRatio, for crisp lines on high-density screens. */
  dpr: number;
  slices: readonly ResolvedSlice[];
  /** The winning slice, lit up after the wheel lands. Others dim. */
  highlightIndex: number | null;
  fontFamily: string;
}

export const LEAD = '#0b0e16';
export const LOCKED_GLASS = '#3a4153';
const STONE_LIGHT = '#4a5269';
const STONE_DARK = '#232838';
const GILT = '#c9a24c';
const FALLBACK_GLASS = '#64748b';

/** Glass colour for a slice: its config colour, or boarded-up grey when locked. */
export function glassColor(slice: ResolvedSlice): string {
  return slice.locked ? LOCKED_GLASS : (slice.option.color ?? FALLBACK_GLASS);
}

export function paintWheel(ctx: CanvasRenderingContext2D, opts: PaintWheelOptions): void {
  const { size, dpr, slices, highlightIndex, fontFamily } = opts;
  const count = slices.length;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, size, size);
  if (count === 0) return;

  const c = size / 2;
  const R = size / 2 - 1;
  const a = sliceAngle(count);
  const lead = Math.max(2.5, R * 0.02);

  // 1. Stone rim.
  const rim = ctx.createRadialGradient(c, c, R * L.glassEdge, c, c, R);
  rim.addColorStop(0, STONE_DARK);
  rim.addColorStop(0.45, STONE_LIGHT);
  rim.addColorStop(1, STONE_DARK);
  ctx.beginPath();
  ctx.arc(c, c, R, 0, Math.PI * 2);
  ctx.fillStyle = rim;
  ctx.fill();

  // 2. Glass panes.
  slices.forEach((slice, i) => {
    const start = toCanvasRadians(i * a);
    const end = toCanvasRadians((i + 1) * a);
    const glass = glassColor(slice);

    ctx.save();
    wedgePath(ctx, c, R * L.glassEdge, start, end);
    ctx.clip();

    // Backlit glass: bright near the hub, deeper toward the rim.
    const fill = ctx.createRadialGradient(c, c, R * L.hub, c, c, R * L.glassEdge);
    fill.addColorStop(0, lighten(glass, slice.locked ? 0.08 : 0.38));
    fill.addColorStop(0.55, glass);
    fill.addColorStop(1, darken(glass, 0.38));
    ctx.fillStyle = fill;
    ctx.fillRect(0, 0, size, size);

    // The outer pane, beyond the tracery arc, is a slightly different pour of glass.
    ctx.beginPath();
    ctx.arc(c, c, R * L.glassEdge, 0, Math.PI * 2);
    ctx.arc(c, c, R * L.tracery, 0, Math.PI * 2, true);
    ctx.fillStyle = withAlpha(darken(glass, 0.5), 0.22);
    ctx.fill();

    // Uneven glass: a seeded speckle so every redraw looks identical.
    const rng = createSeededRng(i * 7919 + count);
    for (let s = 0; s < 70; s++) {
      const r = R * (L.hub + rng() * (L.glassEdge - L.hub));
      const t = start + rng() * (end - start);
      ctx.beginPath();
      ctx.arc(c + r * Math.cos(t), c + r * Math.sin(t), 0.6 + rng() * R * 0.018, 0, Math.PI * 2);
      ctx.fillStyle = rng() > 0.5 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.07)';
      ctx.fill();
    }

    // Locked: boarded up with diagonal slats.
    if (slice.locked) {
      ctx.strokeStyle = 'rgba(12, 14, 22, 0.35)';
      ctx.lineWidth = Math.max(1, R * 0.008);
      const step = Math.max(6, R * 0.045);
      for (let x = -size; x < size * 2; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x + size, size);
        ctx.stroke();
      }
    }

    // After landing, everything but the winner sinks into shadow.
    if (highlightIndex !== null && highlightIndex !== i) {
      ctx.fillStyle = 'rgba(9, 11, 19, 0.58)';
      ctx.fillRect(0, 0, size, size);
    }
    ctx.restore();
  });

  // 3. Lead came: spokes, tracery arc, glass edge, hub ring.
  ctx.strokeStyle = LEAD;
  ctx.lineCap = 'round';
  ctx.lineWidth = lead;
  for (let i = 0; i < count; i++) {
    const t = toCanvasRadians(i * a);
    ctx.beginPath();
    ctx.moveTo(c + R * L.hub * Math.cos(t), c + R * L.hub * Math.sin(t));
    ctx.lineTo(c + R * L.glassEdge * Math.cos(t), c + R * L.glassEdge * Math.sin(t));
    ctx.stroke();
  }
  for (const radius of [L.tracery, L.glassEdge, L.hub]) {
    ctx.beginPath();
    ctx.arc(c, c, R * radius, 0, Math.PI * 2);
    ctx.lineWidth = radius === L.glassEdge ? lead * 1.4 : lead * 0.8;
    ctx.stroke();
  }

  // 4. Icon roundels (the icons themselves are DOM overlays, so they stay crisp Lucide SVGs).
  slices.forEach((slice, i) => {
    const t = toCanvasRadians((i + 0.5) * a);
    const x = c + R * L.roundel * Math.cos(t);
    const y = c + R * L.roundel * Math.sin(t);
    const glass = glassColor(slice);
    const dimmed = highlightIndex !== null && highlightIndex !== i;
    const g = ctx.createRadialGradient(x, y, 0, x, y, R * L.roundelRadius);
    g.addColorStop(0, lighten(glass, slice.locked ? 0.12 : 0.5));
    g.addColorStop(1, glass);
    ctx.beginPath();
    ctx.arc(x, y, R * L.roundelRadius, 0, Math.PI * 2);
    ctx.fillStyle = g;
    ctx.fill();
    if (dimmed) {
      ctx.fillStyle = 'rgba(9, 11, 19, 0.58)';
      ctx.fill();
    }
    ctx.lineWidth = lead * 0.8;
    ctx.strokeStyle = LEAD;
    ctx.stroke();
  });

  // 5. Labels, set tangentially so the slice under the pointer reads upright.
  slices.forEach((slice, i) => {
    const glass = glassColor(slice);
    const dimmed = highlightIndex !== null && highlightIndex !== i;
    const { ink, halo } = inkFor(dimmed ? mix(glass, '#090b13', 0.58) : glass);
    const midRadius = (R * (L.labelInner + L.labelOuter)) / 2;
    const chord = 2 * R * L.labelInner * Math.sin(((a / 2) * Math.PI) / 180);
    const maxWidth = Math.min(chord * 0.92, R * 0.56);
    const maxLineSpan = R * (L.labelOuter - L.labelInner);
    const { lines, fontSize } = fitLabel(ctx, slice.option.label, maxWidth, maxLineSpan, R, fontFamily);
    const lineHeight = fontSize * 1.08;

    ctx.save();
    ctx.translate(c, c);
    ctx.rotate(((i + 0.5) * a * Math.PI) / 180);
    ctx.font = `700 ${fontSize}px ${fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = slice.locked ? 0.62 : dimmed ? 0.55 : 1;
    lines.forEach((line, k) => {
      const y = -midRadius - ((lines.length - 1) / 2 - k) * lineHeight;
      ctx.lineWidth = Math.max(2, fontSize * 0.22);
      ctx.strokeStyle = halo;
      ctx.lineJoin = 'round';
      ctx.strokeText(line, 0, y);
      ctx.fillStyle = ink;
      ctx.fillText(line, 0, y);
    });
    ctx.restore();
  });

  // 6. The winner gets a gilt border along its lead lines.
  if (highlightIndex !== null && highlightIndex < count) {
    const start = toCanvasRadians(highlightIndex * a);
    const end = toCanvasRadians((highlightIndex + 1) * a);
    ctx.save();
    wedgePath(ctx, c, R * L.glassEdge, start, end, R * L.hub);
    ctx.lineWidth = lead * 0.75;
    ctx.strokeStyle = GILT;
    ctx.lineJoin = 'round';
    ctx.shadowColor = withAlpha(GILT, 0.8);
    ctx.shadowBlur = R * 0.05;
    ctx.stroke();
    ctx.restore();
  }

  // 7. Gilt studs on the rim, one per spoke.
  for (let i = 0; i < count; i++) {
    const t = toCanvasRadians(i * a);
    const r = R * ((L.glassEdge + 1) / 2);
    const x = c + r * Math.cos(t);
    const y = c + r * Math.sin(t);
    const stud = ctx.createRadialGradient(x - R * 0.006, y - R * 0.006, 0, x, y, R * 0.022);
    stud.addColorStop(0, '#f3dc9c');
    stud.addColorStop(1, '#8a6a26');
    ctx.beginPath();
    ctx.arc(x, y, R * 0.019, 0, Math.PI * 2);
    ctx.fillStyle = stud;
    ctx.fill();
  }
}

/** A pie wedge (or an annular wedge when `inner` is given). */
function wedgePath(
  ctx: CanvasRenderingContext2D,
  c: number,
  outer: number,
  start: number,
  end: number,
  inner = 0,
): void {
  ctx.beginPath();
  ctx.arc(c, c, outer, start, end);
  if (inner > 0) ctx.arc(c, c, inner, end, start, true);
  else ctx.lineTo(c, c);
  ctx.closePath();
}

/**
 * Wrap a label onto at most two lines, shrinking the font until it fits.
 * Labels are measured before drawing; they are never clipped.
 */
function fitLabel(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxSpan: number,
  R: number,
  fontFamily: string,
): { lines: string[]; fontSize: number } {
  const largest = Math.min(17, Math.max(11, R * 0.068));
  for (let size = largest; size >= 9; size -= 0.5) {
    ctx.font = `700 ${size}px ${fontFamily}`;
    const lines = wrap(ctx, text, maxWidth);
    const fits = lines.every((l) => ctx.measureText(l).width <= maxWidth);
    if (fits && lines.length <= 2 && lines.length * size * 1.08 <= maxSpan) return { lines, fontSize: size };
  }
  // Last resort: two lines, the second shortened with an ellipsis.
  ctx.font = `700 9px ${fontFamily}`;
  const lines = wrap(ctx, text, maxWidth).slice(0, 2);
  let last = lines[1] ?? '';
  while (last.length > 1 && ctx.measureText(`${last}…`).width > maxWidth) last = last.slice(0, -1);
  if (lines.length === 2) lines[1] = `${last}…`;
  return { lines, fontSize: 9 };
}

function wrap(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = '';
  for (const word of words) {
    const attempt = line ? `${line} ${word}` : word;
    if (line && ctx.measureText(attempt).width > maxWidth) {
      lines.push(line);
      line = word;
    } else {
      line = attempt;
    }
  }
  if (line) lines.push(line);
  return balance(ctx, lines, maxWidth);
}

/** "Chosen of the Holy / Sword" reads worse than "Chosen of the / Holy Sword": even out two lines. */
function balance(ctx: CanvasRenderingContext2D, lines: string[], maxWidth: number): string[] {
  if (lines.length !== 2) return lines;
  const words = lines.join(' ').split(' ');
  let best = lines;
  let bestDiff = Infinity;
  for (let k = 1; k < words.length; k++) {
    const a = words.slice(0, k).join(' ');
    const b = words.slice(k).join(' ');
    const wa = ctx.measureText(a).width;
    const wb = ctx.measureText(b).width;
    if (wa > maxWidth || wb > maxWidth) continue;
    const diff = Math.abs(wa - wb);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = [a, b];
    }
  }
  return best;
}
