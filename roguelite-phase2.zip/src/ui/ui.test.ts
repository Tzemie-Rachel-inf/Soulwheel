import { describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../config/gameConfig';
import { getStep } from '../engine/generation';
import { describeEffects, formatOdds, formatPercent, humanizeKey, signed } from './format';
import { OPTION_ICONS } from './icons';

describe('icon registry', () => {
  it('has a component for every icon the config names', () => {
    const missing = Object.values(GAME_CONFIG.steps)
      .flatMap((step) => step.options.map((o) => o.icon))
      .filter((name): name is string => name !== undefined && !(name in OPTION_ICONS));
    expect(missing).toEqual([]);
  });
});

describe('format helpers', () => {
  it('turns any singleton key into a title', () => {
    expect(humanizeKey('demon_lord')).toBe('Demon Lord');
    expect(humanizeKey('holy_sword_bearer')).toBe('Holy Sword Bearer');
    expect(humanizeKey('chosen-hero')).toBe('Chosen Hero');
  });

  it('formats odds and percentages', () => {
    expect(formatOdds(0.071)).toBe('1 in 14');
    expect(formatOdds(0.5)).toBe('1 in 2');
    expect(formatPercent(0.384)).toBe('38%');
    expect(formatPercent(0.004)).toBe('<1%');
    expect(formatPercent(0)).toBe('0%');
    expect(signed(-2)).toBe('−2');
  });

  it('describes effects straight from option data', () => {
    const lord = getStep(GAME_CONFIG, 'fate').options.find((o) => o.id === 'demon_lord');
    if (!lord) throw new Error('missing option');
    expect(describeEffects(lord, GAME_CONFIG)).toEqual([
      '+15 Might',
      '+15 Arcana',
      '+20 Vitality',
      'Gains Mantle of the Demon Lord',
      'Becomes Demon Lord',
      'Claims the one-of-a-kind role Demon Lord',
      'Marked demonic',
    ]);
  });
});
