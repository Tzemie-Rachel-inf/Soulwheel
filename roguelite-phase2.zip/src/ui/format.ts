/** Display helpers. Pure functions, so they're easy to test and reuse. */
import type { CharacterRole, GameConfig, StatKey, WheelOption } from '../engine/types';

export const STAT_LABELS: Record<StatKey, string> = {
  might: 'Might',
  agility: 'Agility',
  intellect: 'Intellect',
  arcana: 'Arcana',
  vitality: 'Vitality',
};

export const ROLE_LABELS: Record<CharacterRole, string> = {
  hero: 'Hero',
  demonLord: 'Demon Lord',
};

/** "+3", "−2" (a real minus sign), "0". */
export function signed(n: number): string {
  if (n > 0) return `+${n}`;
  if (n < 0) return `−${Math.abs(n)}`;
  return '0';
}

/** 0.384 → "38%", 0.004 → "<1%". */
export function formatPercent(p: number): string {
  if (p <= 0) return '0%';
  if (p < 0.01) return '<1%';
  if (p > 0.99 && p < 1) return '>99%';
  return `${Math.round(p * 100)}%`;
}

/** 0.071 → "1 in 14". */
export function formatOdds(p: number): string {
  if (p <= 0) return 'impossible';
  if (p >= 0.995) return 'certain';
  return `1 in ${Math.max(2, Math.round(1 / p))}`;
}

/** 'demon_lord' → 'Demon Lord'. Any singleton key reads as a title, no lookup table needed. */
export function humanizeKey(key: string): string {
  return key
    .split(/[_\-\s]+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

/** What an option does to a character, as short sentences. Read entirely from config data. */
export function describeEffects(option: WheelOption, config: GameConfig): string[] {
  const effects: string[] = [];
  for (const [key, value] of Object.entries(option.statModifiers ?? {})) {
    if (value) effects.push(`${signed(value)} ${STAT_LABELS[key as StatKey] ?? key}`);
  }
  if (option.weaponTierDelta) effects.push(`Weapon tier ${signed(option.weaponTierDelta)}`);
  for (const traitId of option.grantTraits ?? []) {
    effects.push(`Gains ${config.traits[traitId]?.name ?? traitId}`);
  }
  if (option.setRole) effects.push(`Becomes ${ROLE_LABELS[option.setRole]}`);
  if (option.claimSingleton) effects.push(`Claims the one-of-a-kind role ${humanizeKey(option.claimSingleton)}`);
  for (const tag of option.grantTags ?? []) effects.push(`Marked ${tag}`);
  return effects;
}
