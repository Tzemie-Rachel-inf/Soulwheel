/**
 * Config refers to icons by lucide-react name ('Crown'). This registry turns a name
 * into a component.
 *
 * An explicit list (rather than `import { icons } from 'lucide-react'`) keeps the
 * bundle to the icons actually used. When config starts using a new icon, add one
 * line here; `icons.test.ts` fails until you do. Unknown names fall back to a dot.
 */
import {
  Axe,
  Biohazard,
  Bone,
  CircleDot,
  Crown,
  Flame,
  Footprints,
  Gem,
  Ghost,
  Hand,
  Medal,
  Orbit,
  Shield,
  Skull,
  Slice,
  Sparkles,
  Sun,
  Sword,
  Swords,
  Target,
  WandSparkles,
  Wind,
  type LucideIcon,
} from 'lucide-react';

export const OPTION_ICONS: Record<string, LucideIcon> = {
  Axe,
  Biohazard,
  Bone,
  Crown,
  Flame,
  Footprints,
  Gem,
  Ghost,
  Hand,
  Medal,
  Orbit,
  Shield,
  Skull,
  Slice,
  Sparkles,
  Sun,
  Sword,
  Swords,
  Target,
  WandSparkles,
  Wind,
};

export function getOptionIcon(name: string | undefined): LucideIcon {
  return (name !== undefined ? OPTION_ICONS[name] : undefined) ?? CircleDot;
}
