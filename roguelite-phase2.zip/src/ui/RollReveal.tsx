/**
 * What just happened on the wheel, and what to do next.
 * Effects and the next wheel's name are read from config, never hard-coded.
 */
import { AnimatePresence, motion } from 'framer-motion';
import { calculatePowerRating } from '../engine/power';
import type { SpinOutcome } from '../engine/generation';
import type { Character, GameConfig } from '../engine/types';
import type { GenerationPhase } from '../state/generationSession';
import { ROLE_LABELS, describeEffects, formatOdds, humanizeKey } from './format';
import { getOptionIcon } from './icons';
import { inkFor } from './wheel/color';
import { glassColor } from './wheel/paintWheel';

interface RollRevealProps {
  phase: GenerationPhase;
  /** The spin being revealed, or the last one once the character is complete. */
  outcome: SpinOutcome | null;
  character: Character;
  config: GameConfig;
  commitError: string | null;
  onContinue: () => void;
  onCommit: () => void;
  onDiscard: () => void;
}

const enter = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -6 },
  transition: { duration: 0.3, ease: 'easeOut' },
} as const;

export const primaryButton =
  'rounded-md border-2 border-lead bg-gilt px-4 py-2 font-semibold text-ink transition-colors hover:bg-gilt-bright';
export const secondaryButton =
  'rounded-md border-2 border-lead bg-slab-raised px-4 py-2 text-vellum transition-colors hover:bg-slab-hover';

export function RollReveal(props: RollRevealProps) {
  const { phase, outcome } = props;
  const winner = outcome?.roll.winner;
  const announcement = phase === 'revealing' && winner ? `Rolled ${winner.option.label}.` : '';

  return (
    <div>
      <p className="sr-only" aria-live="polite">
        {announcement}
      </p>
      <AnimatePresence mode="wait" initial={false}>
        {phase === 'revealing' && outcome && (
          <motion.div key={`reveal-${outcome.step.id}-${outcome.state.stepsTaken}`} {...enter}>
            <Revealed {...props} outcome={outcome} />
          </motion.div>
        )}
        {phase === 'complete' && (
          <motion.div key="complete" {...enter}>
            <Complete {...props} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Revealed({ outcome, config, onContinue }: RollRevealProps & { outcome: SpinOutcome }) {
  const { option, probability } = outcome.roll.winner;
  const glass = glassColor(outcome.roll.winner);
  const Icon = getOptionIcon(option.icon);
  const effects = describeEffects(option, config);
  const nextStep = option.nextStepId ? config.steps[option.nextStepId] : undefined;

  return (
    <div className="rounded-md border-2 border-lead bg-slab p-5" style={{ boxShadow: `inset 5px 0 0 ${glass}` }}>
      <div className="flex items-start gap-4">
        <span
          aria-hidden="true"
          className="flex size-12 shrink-0 items-center justify-center rounded-full border-[3px] border-lead"
          style={{ background: glass, color: inkFor(glass).ink }}
        >
          <Icon size={22} strokeWidth={2.25} />
        </span>
        <div className="min-w-0">
          <p className="text-sm text-ash">
            {outcome.step.title}, a {formatOdds(probability)} chance
          </p>
          <h3 className="font-display text-3xl leading-tight text-candle">{option.label}</h3>
          {option.description && <p className="mt-1 italic text-vellum">{option.description}</p>}
        </div>
      </div>
      {effects.length > 0 && (
        <ul className="mt-4 flex flex-wrap gap-2" aria-label="Effects">
          {effects.map((effect) => (
            <li key={effect} className="rounded-sm border border-lead bg-slab-raised px-2 py-1 text-sm text-vellum">
              {effect}
            </li>
          ))}
        </ul>
      )}
      <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2">
        <button type="button" onClick={onContinue} className={primaryButton} autoFocus>
          {nextStep ? 'Continue' : 'Finish character'}
        </button>
        {nextStep && <p className="text-sm text-ash">Next: {nextStep.title}</p>}
      </div>
    </div>
  );
}

function Complete({ character, commitError, onCommit, onDiscard }: RollRevealProps) {
  const roles = character.singletonClaims.map(humanizeKey);
  return (
    <div className="rounded-md border-2 border-lead bg-slab p-5">
      <p className="text-sm text-ash">Character complete</p>
      <h3 className="font-display text-3xl leading-tight text-candle">{character.name} is ready</h3>
      <p className="mt-1 text-vellum">
        {ROLE_LABELS[character.role]} with {calculatePowerRating(character)} combat power.
        {roles.length > 0 && ` Entering the world claims: ${roles.join(', ')}.`}
      </p>
      {commitError && (
        <p role="alert" className="mt-3 text-ember">
          {commitError}
        </p>
      )}
      <div className="mt-5 flex flex-wrap gap-3">
        <button type="button" onClick={onCommit} className={primaryButton} autoFocus>
          Enter the world
        </button>
        <button type="button" onClick={onDiscard} className={secondaryButton}>
          Discard
        </button>
      </div>
    </div>
  );
}
