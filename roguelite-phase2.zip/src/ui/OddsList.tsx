/**
 * The true odds for the current wheel. Slices are drawn equal-sized so every option
 * stays visible; this list is where the real probabilities (and lock reasons) live.
 * It is also the wheel's text alternative for screen readers.
 */
import { Lock } from 'lucide-react';
import type { ResolvedSlice } from '../engine/types';
import { formatPercent } from './format';
import { glassColor } from './wheel/paintWheel';

interface OddsListProps {
  slices: readonly ResolvedSlice[];
  winnerIndex: number | null;
  title: string;
}

export function OddsList({ slices, winnerIndex, title }: OddsListProps) {
  return (
    <ul aria-label={`Odds on the ${title}`} className="grid gap-x-8 gap-y-2.5 sm:grid-cols-2">
      {slices.map((slice) => {
        const won = winnerIndex === slice.index;
        return (
          <li
            key={slice.option.id}
            className={`grid grid-cols-[0.75rem_minmax(0,1fr)_auto] items-start gap-x-3 transition-opacity duration-500 ${
              winnerIndex !== null && !won ? 'opacity-55' : ''
            }`}
          >
            <span
              aria-hidden="true"
              className="mt-1.5 size-3 rounded-full border border-lead"
              style={{ background: glassColor(slice) }}
            />
            <span className="min-w-0">
              <span className={`flex items-center gap-1.5 ${slice.locked ? 'text-ash' : 'text-vellum'} ${won ? 'font-semibold text-candle' : ''}`}>
                {slice.locked && <Lock aria-hidden="true" size={13} className="shrink-0" />}
                {slice.option.label}
              </span>
              {slice.locked && <span className="block text-sm text-ash">{slice.lockReason}</span>}
            </span>
            <span className={`text-sm tabular-nums ${slice.locked ? 'text-ash' : 'text-vellum'}`}>
              {slice.locked ? 'Locked' : formatPercent(slice.probability)}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
