/**
 * The persistent world: who holds each one-of-a-kind role, who is alive, and the
 * threat dial. Singleton keys are listed straight from `world.activeSingletons`,
 * so new roles show up here without any UI change.
 */
import { useEffect, useState, type ChangeEvent } from 'react';
import { Crown, User } from 'lucide-react';
import { calculatePowerRating } from '../engine/power';
import type { World } from '../engine/types';
import { ROLE_LABELS, humanizeKey } from './format';

interface WorldPanelProps {
  world: World;
  inspectedId: string | null;
  onInspect: (characterId: string) => void;
  onThreatChange: (level: number) => void;
  onReset: () => void;
}

export function WorldPanel({ world, inspectedId, onInspect, onThreatChange, onReset }: WorldPanelProps) {
  const [confirmingReset, setConfirmingReset] = useState(false);
  const roles = Object.entries(world.activeSingletons);
  const nameOf = (id: string) => world.roster.find((c) => c.id === id)?.name ?? 'an unknown soul';

  useEffect(() => {
    if (!confirmingReset) return;
    const timer = window.setTimeout(() => setConfirmingReset(false), 4000);
    return () => window.clearTimeout(timer);
  }, [confirmingReset]);

  return (
    <section aria-labelledby="world-title" className="rounded-md border-2 border-lead bg-slab">
      <div className="px-5 pb-4 pt-5">
        <h2 id="world-title" className="font-display text-2xl text-candle">
          The world
        </h2>
        <dl className="mt-3 grid grid-cols-3 gap-3 text-sm">
          {[
            ['Living', world.roster.length],
            ['Graveyard', world.graveyard.length],
            ['Hall of fame', world.hallOfFame.length],
          ].map(([label, value]) => (
            <div key={label}>
              <dt className="text-ash">{label}</dt>
              <dd className="text-xl tabular-nums text-vellum">{value}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <h3 className="text-sm text-ash">One-of-a-kind roles</h3>
        {roles.length === 0 ? (
          <p className="mt-1 text-sm text-vellum">Every one-of-a-kind role is open.</p>
        ) : (
          <ul className="mt-2 grid gap-1.5">
            {roles.map(([key, holderId]) => (
              <li key={key} className="flex items-baseline justify-between gap-3">
                <span className="text-vellum">{humanizeKey(key)}</span>
                <span className="truncate text-sm text-ash">held by {nameOf(holderId)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <div className="flex items-baseline justify-between">
          <label htmlFor="threat" className="text-sm text-ash">
            Threat level
          </label>
          <span className="tabular-nums text-vellum">{world.threatLevel.toFixed(1)}</span>
        </div>
        <input
          id="threat"
          type="range"
          min={0}
          max={10}
          step={0.5}
          value={world.threatLevel}
          onChange={(e: ChangeEvent<HTMLInputElement>) => onThreatChange(Number(e.currentTarget.value))}
          className="mt-2 w-full accent-gilt"
        />
        <p className="mt-1 text-sm text-ash">
          A test dial until battles drive it. Higher threat makes curses and darkness likelier and fades blessings.
        </p>
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <h3 className="text-sm text-ash">Living souls</h3>
        {world.roster.length === 0 ? (
          <p className="mt-1 text-sm text-vellum">No one has entered the world yet. Finish a character to add them.</p>
        ) : (
          <ul className="mt-2 grid gap-1">
            {world.roster.map((c) => {
              const Icon = c.role === 'demonLord' ? Crown : User;
              const active = inspectedId === c.id;
              return (
                <li key={c.id}>
                  <button
                    type="button"
                    onClick={() => onInspect(c.id)}
                    aria-pressed={active}
                    className={`grid w-full grid-cols-[1rem_minmax(0,1fr)_auto] items-center gap-3 rounded-md px-2 py-1.5 text-left transition-colors hover:bg-slab-raised ${
                      active ? 'bg-slab-raised' : ''
                    }`}
                  >
                    <Icon aria-hidden="true" size={15} className={c.role === 'demonLord' ? 'text-ember' : 'text-ash'} />
                    <span className="min-w-0">
                      <span className="block truncate text-vellum">{c.name}</span>
                      <span className="block text-xs text-ash">{ROLE_LABELS[c.role]}</span>
                    </span>
                    <span className="text-sm tabular-nums text-vellum">{calculatePowerRating(c)} CP</span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <button
          type="button"
          onClick={() => {
            if (confirmingReset) {
              setConfirmingReset(false);
              onReset();
            } else {
              setConfirmingReset(true);
            }
          }}
          className="text-sm text-ash underline decoration-ash/40 underline-offset-4 hover:text-ember"
        >
          {confirmingReset ? 'Click again to erase this world' : 'Reset world'}
        </button>
      </div>
    </section>
  );
}
