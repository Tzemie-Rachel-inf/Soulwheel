/**
 * The character as the wheels have made them so far.
 *
 * Everything shown is derived from the Character record plus config lookups.
 * Combat Power is recomputed here, never read from storage.
 */
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { MAX_WEAPON_TIER } from '../engine/character';
import { WEAPON_TIER_CP, getPowerBreakdown } from '../engine/power';
import { STAT_KEYS, type Character, type GameConfig } from '../engine/types';
import { CountUp } from './CountUp';
import { ROLE_LABELS, STAT_LABELS, formatOdds, humanizeKey, signed } from './format';

interface CharacterCardProps {
  character: Character;
  /** The character before the latest roll. When set, changes are marked. */
  previous: Character | null;
  config: GameConfig;
  /** Short status line, e.g. "being rolled". */
  status: string;
  /** Shown when inspecting someone other than the character being rolled. */
  onClose?: () => void;
}

const BREAKDOWN = [
  { key: 'stats', label: 'Stats', swatch: 'bg-cp-stats' },
  { key: 'weapon', label: 'Weapon', swatch: 'bg-cp-weapon' },
  { key: 'traits', label: 'Traits', swatch: 'bg-cp-traits' },
] as const;

export function CharacterCard({ character, previous, config, status, onClose }: CharacterCardProps) {
  const power = getPowerBreakdown(character);
  const before = previous ? getPowerBreakdown(previous) : null;
  const cpDelta = before ? power.total - before.total : 0;
  const statMax = Math.max(40, Math.ceil(Math.max(...STAT_KEYS.map((k) => character.stats[k])) / 10) * 10);
  const barTotal = Math.max(1, power.stats + Math.max(0, power.weapon) + Math.max(0, power.traits));

  return (
    <section aria-labelledby="character-name" className="rounded-md border-2 border-lead bg-slab">
      <header className="flex items-start gap-3 px-5 pb-4 pt-5">
        <div className="min-w-0 flex-1">
          <p className="text-sm text-ash">
            {ROLE_LABELS[character.role]}, {status}
          </p>
          <h2 id="character-name" className="font-display text-3xl leading-tight text-candle">
            {character.name}
          </h2>
          {character.singletonClaims.length > 0 && (
            <ul className="mt-2 flex flex-wrap gap-2">
              {character.singletonClaims.map((key) => (
                <li
                  key={key}
                  className="rounded-sm border border-gilt/70 bg-gilt/10 px-2 py-0.5 text-sm text-candle"
                >
                  One of a kind: {humanizeKey(key)}
                </li>
              ))}
            </ul>
          )}
        </div>
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1 rounded-md border-2 border-lead bg-slab-raised px-2.5 py-1.5 text-sm text-vellum hover:bg-slab-hover"
          >
            <X aria-hidden="true" size={14} />
            Back to the current roll
          </button>
        )}
      </header>

      {/* Combat power: the one hero figure on the page. */}
      <div className="border-t-2 border-lead px-5 py-4">
        <p className="text-sm text-ash">Combat power</p>
        <p className="mt-1 flex items-baseline gap-3">
          <CountUp value={power.total} className="text-6xl font-semibold leading-none text-candle" />
          {cpDelta !== 0 && <span className="text-lg text-moss">{signed(cpDelta)}</span>}
        </p>
        <div
          className="mt-4 flex h-2.5 gap-0.5 overflow-hidden rounded-r-[4px]"
          role="img"
          aria-label={`Stats ${power.stats}, weapon ${power.weapon}, traits ${power.traits}`}
        >
          {BREAKDOWN.map(({ key, label, swatch }) =>
            power[key] > 0 ? (
              <span
                key={key}
                title={`${label}: ${power[key]}`}
                className={`${swatch} h-full transition-[flex-grow] duration-700 ease-out`}
                style={{ flexGrow: power[key] / barTotal, flexBasis: 0 }}
              />
            ) : null,
          )}
        </div>
        <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-sm">
          {BREAKDOWN.map(({ key, label, swatch }) => (
            <li key={key} className="flex items-center gap-2 text-ash">
              <span aria-hidden="true" className={`size-2.5 rounded-[2px] ${swatch}`} />
              {label}
              <span className="tabular-nums text-vellum">{power[key]}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <h3 className="sr-only">Stats</h3>
        <ul className="grid gap-2">
          {STAT_KEYS.map((key) => {
            const value = character.stats[key];
            const delta = previous ? value - previous.stats[key] : 0;
            return (
              <li key={key} className="grid grid-cols-[5.5rem_minmax(0,1fr)_2rem_2rem] items-center gap-3">
                <span className="text-sm text-vellum">{STAT_LABELS[key]}</span>
                <span className="h-1.5 rounded-r-[3px] bg-cp-stats-track">
                  <span
                    className="block h-full rounded-r-[3px] bg-cp-stats transition-[width] duration-700 ease-out"
                    style={{ width: `${Math.min(100, (value / statMax) * 100)}%` }}
                  />
                </span>
                <span className="text-right tabular-nums text-vellum">{value}</span>
                <span className={`text-right text-sm tabular-nums ${delta > 0 ? 'text-moss' : 'text-ember'}`}>
                  {delta !== 0 ? signed(delta) : ''}
                </span>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <div className="flex items-baseline justify-between gap-3">
          <h3 className="text-sm text-ash">Weapon tier</h3>
          <p className="text-sm text-ash">
            <span className="tabular-nums text-vellum">{character.weaponTier}</span> of {MAX_WEAPON_TIER}, worth{' '}
            <span className="tabular-nums text-vellum">{character.weaponTier * WEAPON_TIER_CP}</span> CP
          </p>
        </div>
        <div className="mt-2 flex gap-0.5" aria-hidden="true">
          {Array.from({ length: MAX_WEAPON_TIER }, (_, i) => (
            <span
              key={i}
              className={`h-2 flex-1 transition-colors duration-500 ${i < character.weaponTier ? 'bg-cp-weapon' : 'bg-cp-weapon-track'} ${i === MAX_WEAPON_TIER - 1 ? 'rounded-r-[3px]' : ''}`}
            />
          ))}
        </div>
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <h3 className="text-sm text-ash">Traits</h3>
        {character.traits.length === 0 ? (
          <p className="mt-1 text-sm text-ash">None yet. The wheels decide what this soul carries.</p>
        ) : (
          <ul className="mt-2 grid gap-3">
            <AnimatePresence initial={false}>
              {character.traits.map((trait) => (
                <motion.li
                  key={trait.id}
                  layout
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="flex items-start gap-3"
                >
                  <span aria-hidden="true" className="mt-2 size-2.5 shrink-0 rounded-[2px] bg-cp-traits" />
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-vellum">{trait.name}</p>
                    <p className="text-sm text-ash">{trait.description}</p>
                  </div>
                  <span className="text-sm tabular-nums text-vellum">{signed(trait.power)}</span>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        )}
      </div>

      <div className="border-t-2 border-lead px-5 py-4">
        <h3 className="text-sm text-ash">Path through the wheels</h3>
        {character.history.length === 0 ? (
          <p className="mt-1 text-sm text-ash">Nothing rolled yet.</p>
        ) : (
          <ol className="mt-2 grid gap-2">
            {character.history.map((roll) => {
              const step = config.steps[roll.stepId];
              const option = step?.options.find((o) => o.id === roll.optionId);
              return (
                <li key={roll.stepId + roll.optionId} className="flex items-baseline justify-between gap-3">
                  <span className="min-w-0">
                    <span className="block text-xs text-ash">{step?.title ?? roll.stepId}</span>
                    <span className="text-vellum">{option?.label ?? roll.optionId}</span>
                  </span>
                  <span className="shrink-0 text-sm text-ash">{formatOdds(roll.probability)}</span>
                </li>
              );
            })}
          </ol>
        )}
      </div>
    </section>
  );
}
