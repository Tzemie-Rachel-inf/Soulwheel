/**
 * Phase 2 shell: the wheel, the character it is building, and the world they enter.
 *
 * There is no wheel-specific logic here. Which wheel shows, what it contains and
 * what comes next all come from GAME_CONFIG through the engine.
 */
import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { GAME_CONFIG } from './config/gameConfig';
import type { GameConfig } from './engine/types';
import { validateGameConfig } from './engine/validate';
import { useCharacterGeneration } from './state/useCharacterGeneration';
import { useWorld } from './state/useWorld';
import { CharacterCard } from './ui/CharacterCard';
import { OddsList } from './ui/OddsList';
import { RollReveal } from './ui/RollReveal';
import { WorldPanel } from './ui/WorldPanel';
import { SpinWheel } from './ui/wheel/SpinWheel';
import { withAlpha } from './ui/wheel/color';
import { glassColor } from './ui/wheel/paintWheel';

export default function App() {
  const report = useMemo(() => validateGameConfig(GAME_CONFIG), []);
  if (report.errors.length > 0) return <ConfigErrors errors={report.errors} />;
  return <Game config={GAME_CONFIG} />;
}

function Game({ config }: { config: GameConfig }) {
  const { world, commit, setThreatLevel, resetWorld } = useWorld();
  const generation = useCharacterGeneration(config, world);
  const { session, view } = generation;
  const [inspectedId, setInspectedId] = useState<string | null>(null);
  const [commitError, setCommitError] = useState<string | null>(null);

  const inspected = inspectedId ? (world.roster.find((c) => c.id === inspectedId) ?? null) : null;
  const landed = session.phase === 'revealing' || session.phase === 'complete';
  const winner = landed && view.winnerIndex !== null ? view.slices[view.winnerIndex] : undefined;
  const glow = winner ? glassColor(winner) : null;

  const handleCommit = () => {
    const result = commit(view.character);
    if (result.ok) {
      setCommitError(null);
      generation.restart();
    } else {
      setCommitError(result.message);
    }
  };

  const handleDiscard = () => {
    setCommitError(null);
    generation.restart();
  };

  const handleReset = () => {
    resetWorld();
    setInspectedId(null);
    setCommitError(null);
    generation.restart();
  };

  return (
    <div className="relative min-h-dvh overflow-x-clip">
      {/* The room takes on the colour of whichever pane the light comes through. */}
      <div aria-hidden="true" className="pointer-events-none fixed inset-0">
        <div
          className="absolute inset-0"
          style={{ background: 'radial-gradient(70rem 46rem at 28% 36%, rgba(124, 136, 182, 0.12), rgba(0, 0, 0, 0) 70%)' }}
        />
        <AnimatePresence>
          {glow && (
            <motion.div
              key={glow}
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.2, ease: 'easeOut' }}
              style={{
                background: `radial-gradient(60rem 42rem at 28% 36%, ${withAlpha(glow, 0.3)}, rgba(0, 0, 0, 0) 70%)`,
              }}
            />
          )}
        </AnimatePresence>
      </div>

      <header className="relative mx-auto flex max-w-7xl flex-wrap items-baseline justify-between gap-x-6 gap-y-1 px-4 pt-6 sm:px-8">
        <p className="font-display text-2xl text-candle">Soulwheel</p>
        <p className="text-sm text-ash">Roll a soul. Send it into the world.</p>
      </header>

      <main className="relative mx-auto grid max-w-7xl gap-8 px-4 pb-20 pt-6 sm:px-8 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] lg:gap-12">
        <section aria-labelledby="wheel-title" className="min-w-0">
          <h1 id="wheel-title" className="font-display text-4xl leading-none text-candle sm:text-5xl">
            {view.step?.title ?? 'No wheel'}
          </h1>
          {view.step?.subtitle && <p className="mt-2 text-lg text-ash">{view.step.subtitle}</p>}

          <div className="mt-8">
            <SpinWheel
              slices={view.slices}
              spin={generation.spinRequest}
              highlightIndex={landed ? view.winnerIndex : null}
              canSpin={view.canSpin}
              onSpinRequest={generation.spin}
              onSettled={generation.settle}
              label={view.step?.title ?? 'Wheel'}
            />
          </div>

          {generation.error && (
            <p role="alert" className="mt-4 text-ember">
              {generation.error}
            </p>
          )}
          {session.phase === 'ready' && !view.canSpin && !generation.error && (
            <p className="mt-4 text-ember">Every slice on this wheel is locked right now.</p>
          )}

          <div className="mt-8">
            <RollReveal
              phase={session.phase}
              outcome={session.pending ?? session.last}
              character={view.character}
              config={config}
              commitError={commitError}
              onContinue={generation.next}
              onCommit={handleCommit}
              onDiscard={handleDiscard}
            />
          </div>

          {view.step && (
            <div className="mt-8">
              <h2 className="text-sm text-ash">Odds on this wheel</h2>
              <div className="mt-3">
                <OddsList
                  slices={view.slices}
                  winnerIndex={landed ? view.winnerIndex : null}
                  title={view.step.title}
                />
              </div>
            </div>
          )}
        </section>

        <aside className="flex min-w-0 flex-col gap-6" aria-label="Character and world">
          {inspected ? (
            <CharacterCard
              character={inspected}
              previous={null}
              config={config}
              status="in the world"
              onClose={() => setInspectedId(null)}
            />
          ) : (
            <CharacterCard
              character={view.character}
              previous={view.previous}
              config={config}
              status={session.phase === 'complete' ? 'ready to enter the world' : 'being rolled'}
            />
          )}
          <WorldPanel
            world={world}
            inspectedId={inspectedId}
            onInspect={(id) => setInspectedId((current) => (current === id ? null : id))}
            onThreatChange={setThreatLevel}
            onReset={handleReset}
          />
        </aside>
      </main>
    </div>
  );
}

function ConfigErrors({ errors }: { errors: string[] }) {
  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-display text-4xl text-candle">The wheel config has errors</h1>
      <p className="mt-2 text-vellum">Fix these in src/config/gameConfig.ts, then reload.</p>
      <ul className="mt-6 grid gap-2">
        {errors.map((e) => (
          <li key={e} className="rounded-md border-2 border-lead bg-slab px-4 py-2 text-ember">
            {e}
          </li>
        ))}
      </ul>
    </main>
  );
}
